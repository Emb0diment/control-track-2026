#include "peripherals.h"
#include <float.h>
#include <math.h>
#include <string.h>
_Static_assert(sizeof(float) == 4 && FLT_RADIX == 2 && FLT_MANT_DIG == 24,
               "IEEE754 binary32 required");
size_t VofaEncode(const float a[VOFA_CHANNELS], uint8_t out[VOFA_FRAME_BYTES]) {
    for (int i = 0; i < VOFA_CHANNELS; i++) {
        uint32_t bits;
        float v = isfinite(a[i]) ? a[i] : 0;
        memcpy(&bits, &v, 4);
        for (int j = 0; j < 4; j++)
            out[4 * i + j] = (uint8_t)(bits >> (8 * j));
    }
    const uint8_t tail[4] = {0, 0, 0x80, 0x7f};
    memcpy(out + 4 * VOFA_CHANNELS, tail, 4);
    return VOFA_FRAME_BYTES;
}
