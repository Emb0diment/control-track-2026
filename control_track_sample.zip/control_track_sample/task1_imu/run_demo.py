"""One-command host entry: python run_demo.py [--check-only]."""
from pathlib import Path
import subprocess,sys,shutil,os
root=Path(__file__).resolve().parent
compiler=next((shutil.which(x) for x in ['cc','gcc','clang'] if shutil.which(x)),None)
if not compiler:
 sys.exit('C compiler missing. Install GCC/Clang (Windows: MSYS2 UCRT64 GCC) and add it to PATH.')
(root/'build').mkdir(exist_ok=True)
sources=['core/calibration.c','core/ekf.c','drivers/mpu6050.c','app/strobe.c','app/imu_service.c','protocol/vofa.c']
ext='.exe' if os.name=='nt' else ''
log=[]
def run(cmd):
 print('>', ' '.join(map(str,cmd)),flush=True)
 p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(p.stdout,end='');log.append('$ '+' '.join(map(str,cmd))+'\n'+p.stdout)
 if p.returncode:
  (root/'results/verification.txt').write_text('\n'.join(log),encoding='utf-8');sys.exit(p.returncode)
run([compiler,'--version'])
for name,entry in [('imu_cli','host/imu_cli.c'),('test_core','tests/test_core.c')]:
 run([compiler,'-std=c11','-O2','-Wall','-Wextra','-Werror','-Wpedantic','-Iinclude','-Iconfig',*sources,entry,'-lm','-o',str(root/'build'/(name+ext))])
run([str(root/'build'/('test_core'+ext))])
# This is only an API-stub syntax check of the RTOS adapter, not target validation.
run([compiler,'-std=c11','-Wall','-Wextra','-Werror','-Iinclude','-Iconfig','-Itests/rtos_stubs','-fsyntax-only','ports/freertos/app_runtime.c'])
if '--check-only' not in sys.argv:
 try:import numpy,matplotlib
 except ImportError:sys.exit('Plot dependencies missing. Run: python -m pip install -r requirements.txt')
 run([sys.executable,'tools/demo.py'])
(root/'results/verification.txt').write_text('\n'.join(log),encoding='utf-8')
print('Done. Open results/ for checks and SYNTHETIC plots. Hardware has NOT been tested.')
