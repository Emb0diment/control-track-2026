#include "ekf_defaults.h"
#include "imu.h"
#include <math.h>
#include <string.h>
static float clamp(float x, float lo, float hi) {
    return fminf(hi, fmaxf(lo, x));
}
static float norm3(const float v[3]) {
    return sqrtf(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}
static void normalize(float q[4]) {
    float n = sqrtf(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    for (int i = 0; i < 4; i++)
        q[i] /= n;
}
static void multiply(const float a[4], const float b[4], float c[4]) {
    float r[4] = {a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
                  a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
                  a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
                  a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]};
    memcpy(c, r, sizeof(r));
}
void ImuQuatStep(float q[4], const float w[3], float dt) {
    float n = norm3(w), angle = n * dt, scale = n > 1e-7f ? sinf(angle / 2) / n : dt / 2;
    float dq[4] = {cosf(angle / 2), w[0] * scale, w[1] * scale, w[2] * scale};
    multiply(q, dq, q);
    normalize(q);
}
void ImuGravityBody(const float q[4], float h[3]) {
    h[0] = 2 * (q[1] * q[3] - q[0] * q[2]);
    h[1] = 2 * (q[2] * q[3] + q[0] * q[1]);
    h[2] = 1 - 2 * (q[1] * q[1] + q[2] * q[2]);
}
void ImuEulerFromQuat(const float q[4], float r[3]) {
    r[0] = atan2f(2 * (q[0] * q[1] + q[2] * q[3]), 1 - 2 * (q[1] * q[1] + q[2] * q[2]));
    r[1] = asinf(clamp(2 * (q[0] * q[2] - q[3] * q[1]), -1, 1));
    r[2] = atan2f(2 * (q[0] * q[3] + q[1] * q[2]), 1 - 2 * (q[2] * q[2] + q[3] * q[3]));
}
void ImuEkfGetEuler(const ImuEkf *e, float r[3]) {
    ImuEulerFromQuat(e->q, r);
}
static void skew(const float v[3], float s[3][3]) {
    memset(s, 0, 9 * sizeof(float));
    s[0][1] = -v[2];
    s[0][2] = v[1];
    s[1][0] = v[2];
    s[1][2] = -v[0];
    s[2][0] = -v[1];
    s[2][1] = v[0];
}
ImuEkfConfig ImuEkfDefaultConfig(void) {
    ImuEkfConfig c = {EKF_GYRO_NOISE,      EKF_BIAS_RW, EKF_ACCEL_DIRECTION_SIGMA,
                      EKF_ACCEL_NORM_GATE, EKF_DT_MIN,  EKF_DT_MAX};
    return c;
}
int ImuEkfInit(ImuEkf *e, const float a[3], const ImuEkfConfig *cfg) {
    ImuEkfConfig c = cfg ? *cfg : ImuEkfDefaultConfig();
    float n = norm3(a);
    if (!isfinite(n) || fabsf(n - IMU_G) > 0.2f * IMU_G)
        return -1;
    const float values[] = {c.gyro_noise, c.bias_rw, c.accel_direction_sigma,
                            c.accel_gate, c.dt_min,  c.dt_max};
    for (int i = 0; i < 6; i++)
        if (!isfinite(values[i]) || values[i] <= 0)
            return -1;
    if (c.dt_max <= c.dt_min || c.accel_gate >= 1)
        return -1;
    memset(e, 0, sizeof(*e));
    e->cfg = c;
    float roll = atan2f(a[1], a[2]), pitch = atan2f(-a[0], sqrtf(a[1] * a[1] + a[2] * a[2]));
    float cr = cosf(roll / 2), sr = sinf(roll / 2), cp = cosf(pitch / 2), sp = sinf(pitch / 2);
    e->q[0] = cr * cp;
    e->q[1] = sr * cp;
    e->q[2] = cr * sp;
    e->q[3] = -sr * sp;
    for (int i = 0; i < 6; i++)
        e->P[i][i] = i < 3 ? 0.03f * 0.03f : 0.02f * 0.02f;
    return 0;
}
static int inverse3(float a[3][3], float out[3][3]) {
    float x[3][6];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 6; j++)
            x[i][j] = j < 3 ? a[i][j] : (j - 3 == i ? 1 : 0);
    for (int k = 0; k < 3; k++) {
        int p = k;
        for (int i = k + 1; i < 3; i++)
            if (fabsf(x[i][k]) > fabsf(x[p][k]))
                p = i;
        if (!isfinite(x[p][k]) || fabsf(x[p][k]) < 1e-12f)
            return -1;
        for (int j = 0; j < 6; j++) {
            float v = x[k][j];
            x[k][j] = x[p][j];
            x[p][j] = v;
        }
        float d = x[k][k];
        for (int j = 0; j < 6; j++)
            x[k][j] /= d;
        for (int i = 0; i < 3; i++)
            if (i != k) {
                float f = x[i][k];
                for (int j = 0; j < 6; j++)
                    x[i][j] -= f * x[k][j];
            }
    }
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            out[i][j] = x[i][j + 3];
    return 0;
}
/* dst = F*P*F'. Arrays local, never heap allocated. */
static void sandwich(float F[6][6], float P[6][6], float dst[6][6]) {
    float t[6][6] = {{0}};
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++)
            for (int k = 0; k < 6; k++)
                t[i][j] += F[i][k] * P[k][j];
    memset(dst, 0, 36 * sizeof(float));
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++)
            for (int k = 0; k < 6; k++)
                dst[i][j] += t[i][k] * F[j][k];
}
int ImuEkfUpdate(ImuEkf *e, const float gyro[3], const float accel[3], float dt) {
    if (!isfinite(dt) || dt < e->cfg.dt_min || dt > e->cfg.dt_max)
        return IMU_EKF_BAD_INPUT;
    for (int i = 0; i < 3; i++)
        if (!isfinite(gyro[i]) || !isfinite(accel[i]) || fabsf(gyro[i]) > 40 ||
            fabsf(accel[i]) > 200)
            return IMU_EKF_BAD_INPUT;
    ImuEkf v = *e;
    float w[3];
    for (int i = 0; i < 3; i++)
        w[i] = gyro[i] - v.bias[i];
    ImuQuatStep(v.q, w, dt);
    float sw[3][3], F[6][6] = {{0}}, next[6][6];
    skew(w, sw);
    for (int i = 0; i < 6; i++)
        F[i][i] = 1;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++)
            F[i][j] -= sw[i][j] * dt;
        F[i][i + 3] = -dt;
    }
    sandwich(F, v.P, next);
    float ng = v.cfg.gyro_noise * v.cfg.gyro_noise, nb = v.cfg.bias_rw * v.cfg.bias_rw;
    for (int i = 0; i < 3; i++) {
        next[i][i] += ng * dt + nb * dt * dt * dt / 3;
        next[i][i + 3] -= nb * dt * dt / 2;
        next[i + 3][i] -= nb * dt * dt / 2;
        next[i + 3][i + 3] += nb * dt;
    }
    memcpy(v.P, next, sizeof(next));
    int status = IMU_EKF_ACCEL_SKIPPED;
    float n = norm3(accel), dev = fabsf(n - IMU_G) / IMU_G;
    if (n > 1e-5f && dev <= v.cfg.accel_gate) {
        float h[3], sh[3][3], H[3][6] = {{0}}, PH[6][3] = {{0}}, S[3][3] = {{0}}, inv[3][3],
                              K[6][3] = {{0}}, dx[6] = {0};
        ImuGravityBody(v.q, h);
        skew(h, sh);
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                H[i][j] = sh[i][j];
        /* Soft variance inflation inside hard norm gate. */
        float ratio = dev / v.cfg.accel_gate, R = v.cfg.accel_direction_sigma *
                                                  v.cfg.accel_direction_sigma *
                                                  (1 + 24 * ratio * ratio);
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 3; j++)
                for (int k = 0; k < 6; k++)
                    PH[i][j] += v.P[i][k] * H[j][k];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 6; k++)
                    S[i][j] += H[i][k] * PH[k][j];
                if (i == j)
                    S[i][j] += R;
            }
        if (inverse3(S, inv))
            return IMU_EKF_NUMERIC;
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 3; j++)
                for (int k = 0; k < 3; k++)
                    K[i][j] += PH[i][k] * inv[k][j];
        if (v.freeze_bias)
            for (int i = 3; i < 6; i++)
                for (int j = 0; j < 3; j++)
                    K[i][j] = 0;
        for (int i = 0; i < 6; i++)
            for (int j = 0; j < 3; j++)
                dx[i] += K[i][j] * (accel[j] / n - h[j]);
        /* Skip a gross innovation outside the small-error linearization region. */
        if (norm3(dx) < 0.35f) {
            ImuQuatStep(v.q, dx, 1);
            for (int i = 0; i < 3; i++)
                v.bias[i] += dx[i + 3];
            float M[6][6] = {{0}};
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 6; j++) {
                    M[i][j] = i == j ? 1 : 0;
                    for (int k = 0; k < 3; k++)
                        M[i][j] -= K[i][k] * H[k][j];
                }
            sandwich(M, v.P, next);
            /* Joseph stabilized covariance */
            for (int i = 0; i < 6; i++)
                for (int j = 0; j < 6; j++)
                    for (int k = 0; k < 3; k++)
                        next[i][j] += R * K[i][k] * K[j][k];
            /* Right-error reset Jacobian: I - 0.5*[dtheta]x. */
            float sd[3][3];
            skew(dx, sd);
            memset(M, 0, sizeof(M));
            for (int i = 0; i < 6; i++)
                M[i][i] = 1;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    M[i][j] -= 0.5f * sd[i][j];
            sandwich(M, next, v.P);
            status = IMU_EKF_OK;
        }
    }
    for (int i = 0; i < 6; i++)
        for (int j = i; j < 6; j++) {
            float a = 0.5f * (v.P[i][j] + v.P[j][i]);
            if (!isfinite(a))
                return IMU_EKF_NUMERIC;
            if (i == j) {
                if (a < -1e-8f)
                    return IMU_EKF_NUMERIC;
                a = fmaxf(a, 1e-12f);
            }
            v.P[i][j] = v.P[j][i] = a;
        }
    for (int i = 0; i < 4; i++)
        if (!isfinite(v.q[i]))
            return IMU_EKF_NUMERIC;
    for (int i = 0; i < 3; i++)
        if (!isfinite(v.bias[i]))
            return IMU_EKF_NUMERIC;
    if (status == IMU_EKF_OK)
        v.accepted++;
    else
        v.rejected++;
    *e = v;
    return status;
}
