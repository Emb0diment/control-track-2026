#include "imu.h"
#include <math.h>
#include <string.h>
void ImuStatsPush(ImuStats *s, const ImuSample *v) {
    s->n++;
    for (int i = 0; i < 6; i++) {
        double x = i < 3 ? v->a[i] : v->w[i - 3];
        double d = x - s->mean[i];
        s->mean[i] += d / s->n;
        s->m2[i] += d * (x - s->mean[i]);
    }
}
void ImuCalibrationIdentity(ImuCalibration *c) {
    memset(c, 0, sizeof(*c));
    for (int i = 0; i < 3; i++)
        c->scale[i] = 1;
}
int ImuCalibrate(const ImuStats f[6], ImuCalibration *out) {
    ImuCalibration c;
    ImuCalibrationIdentity(&c);
    unsigned total = 0;
    for (int j = 0; j < 6; j++) {
        if (f[j].n < 100)
            return -1;
        for (int i = 0; i < 6; i++) {
            if (!isfinite(f[j].mean[i]) || !isfinite(f[j].m2[i]) || f[j].m2[i] < 0)
                return -2;
            double sd = sqrt(f[j].m2[i] / (f[j].n - 1));
            if (sd > (i < 3 ? 0.25 : 0.025))
                return -3;
            /* example stationary thresholds */
        }
        total += f[j].n;
        for (int i = 0; i < 3; i++)
            c.gyro_bias[i] += (float)(f[j].mean[i + 3] * f[j].n);
    }
    for (int i = 0; i < 3; i++) {
        double pos = f[2 * i].mean[i], neg = f[2 * i + 1].mean[i], span = pos - neg;
        if (span < 1.5 * IMU_G || span > 2.5 * IMU_G)
            return -4;
        c.offset[i] = (float)((pos + neg) / 2);
        c.scale[i] = (float)(2 * IMU_G / span);
        c.gyro_bias[i] /= total;
        if (fabsf(c.gyro_bias[i]) > 0.2f)
            return -5;
    }
    /* Reject mislabeled/tilted faces; simple diagonal model cannot fix misalignment. */
    for (int j = 0; j < 6; j++)
        for (int i = 0; i < 3; i++) {
            double v = (f[j].mean[i] - c.offset[i]) * c.scale[i];
            double target = j / 2 == i ? (j % 2 ? -IMU_G : IMU_G) : 0;
            if (fabs(v - target) > 0.08 * IMU_G)
                return -6;
        }
    *out = c;
    return 0;
}
void ImuApplyCalibration(const ImuCalibration *c, const ImuSample *in, ImuSample *out) {
    ImuSample v = *in;
    for (int i = 0; i < 3; i++) {
        v.a[i] = (in->a[i] - c->offset[i]) * c->scale[i];
        v.w[i] = in->w[i] - c->gyro_bias[i];
    }
    *out = v;
}
