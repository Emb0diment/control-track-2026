# IMU 工程样例：先运行，再读分层，再接硬件

这份工程覆盖任务一的 C 标定、四元数误差状态 EKF、FreeRTOS 数据流、VOFA+ 展示以及低功率 LED 频闪加分项。电脑演示复用板端同一份 C 算法。

**状态：电脑 C 算法与应用状态机已经测试；STM32 适配代码尚未用真实 SDK 编译、烧录或实测。没有真实六面标定、硬件动态数据或板端运行成绩。** `SYNTHETIC_` 前缀全部是合成样例，不能充当参赛实测材料。

## 1. 一条命令运行演示

需要 Python 3.10+ 和 GCC/Clang。Windows 可用 MSYS2 UCRT64 的 GCC；安装后确保 `gcc --version` 可运行。Python 负责数据与图表，EKF 完全由 C 执行。

在本目录打开终端，首次安装绘图依赖：

```bash
python -m pip install -r requirements.txt
```

然后运行：

```bash
python run_demo.py
```

入口会依次严格编译 C、运行模块与状态机测试、对 FreeRTOS 调度文件做声明桩语法检查、生成合成数据、执行 C 标定与回放、输出四类图表。
只检查 C 而不装 Python 绘图库，可运行 `python run_demo.py --check-only`。
Linux/macOS 也可使用 `make test`、`make demo`。

`results/` 已附本次实际运行的结果。重点先看 `SYNTHETIC_attitude.png` 和 `verification.txt`。
重复演示只覆盖 `SYNTHETIC_` 文件及 verification.txt；真实日志请用其他名称保存。

## 2. 按这个顺序理解工程

| 顺序 | 入口 | 要理解的问题 |
|---|---|---|
| 1 | docs/ARCHITECTURE.md | 每层做什么，哪些文件可以独立运行 |
| 2 | include/imu.h | 输入、输出、坐标、单位与状态接口 |
| 3 | core/calibration.c | 原始 SI 数据怎样变成标定后的数据 |
| 4 | core/ekf.c + docs/ALGORITHM.md | 预测、重力更新、零偏、协方差 |
| 5 | app/imu_service.c | 启动静止检测、掉线、异常周期与恢复 |
| 6 | ports/freertos/app_runtime.c | 周期任务、队列和谁拥有状态 |
| 7 | docs/HARDWARE.md | 接线、CubeMX、采集和烧录步骤 |

## 3. 修改只去相应层

- 改采样、遥测周期和任务栈：`config/app_config.h`。
- 改示例 Q/R：`config/ekf_defaults.h`；也能给 `ImuEkfInit` 传入自定义配置。
- 换真实标定：`config/calibration_board.h`。
- 换传感器：替换 `drivers/` 及其 SI 数据接口，保留 core 与 app。
- 换 STM32 型号或引脚：实现 `include/board_port.h`，不要改 EKF。
- 换 RTOS：替换 `ports/freertos/`，保留应用服务与核心算法。

默认标定标志为 0：硬件可以输出原始数据，但不会假装已经完成标定而启动 EKF。必须自行采集并生成真实标定头文件。

## 4. 交付与验收

参数、算法假设：docs/ALGORITHM.md；传感器配置、实时性与任务设置：docs/HARDWARE.md；32 通道及命令应答：docs/PROTOCOL.md；赛道逐项对照与面试：docs/ACCEPTANCE.md。

没有指定你的实际开发板型号，所以硬件交付是 STM32F4 HAL 适配样例，不含凭空假定的完整 CubeMX .ioc、链接脚本或可直接烧录固件。确定板卡后，按 HARDWARE.md 生成工程并接入即可继续验证。
