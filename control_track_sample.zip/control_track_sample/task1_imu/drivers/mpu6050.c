#include "peripherals.h"
#include <stdint.h>
static int write_reg(Mpu6050 *m, uint8_t r, uint8_t v) {
    return m->write(m->ctx, m->addr7, r, v);
}
int Mpu6050Init(Mpu6050 *m) {
    uint8_t id = 0;
    if (!m || !m->read || !m->write || !m->delay_ms || (m->addr7 != 0x68 && m->addr7 != 0x69))
        return -1;
    if (m->read(m->ctx, m->addr7, 0x75, &id, 1) || id != 0x68)
        return -2;
    if (write_reg(m, 0x6B, 0x80))
        return -3;
    m->delay_ms(m->ctx, 100);
    const uint8_t regs[] = {0x6B, 0x6C, 0x1A, 0x19, 0x1B, 0x1C, 0x38};
    const uint8_t vals[] = {0x01, 0x00, 0x03, 0x04, 0x08, 0x08, 0x01};
    for (size_t i = 0; i < sizeof(regs); i++)
        if (write_reg(m, regs[i], vals[i]))
            return -4;
    m->delay_ms(m->ctx, 100);
    for (size_t i = 0; i < sizeof(regs); i++) {
        uint8_t v = 0;
        if (m->read(m->ctx, m->addr7, regs[i], &v, 1) || v != vals[i])
            return -5;
    }
    return 0;
}
static int16_t s16(const uint8_t *b) {
    int v = (int)b[0] * 256 + b[1];
    return (int16_t)(v >= 32768 ? v - 65536 : v);
}
int Mpu6050Read(Mpu6050 *m, ImuSample *out, uint32_t ts) {
    uint8_t ready = 0, b[14];
    if (m->read(m->ctx, m->addr7, 0x3A, &ready, 1))
        return -1;
    if (!(ready & 1))
        return 1;
    if (m->read(m->ctx, m->addr7, 0x3B, b, sizeof(b)))
        return -2;
    ImuSample v;
    v.stamp_us = ts;
    for (int i = 0; i < 3; i++) {
        v.a[i] = s16(b + 2 * i) * (IMU_G / 8192.0f);
        v.w[i] = s16(b + 8 + 2 * i) * (IMU_PI / (180.0f * 65.5f));
    }
    *out = v;
    return 0;
}
