/* EXAMPLE STM32F4 HAL adapter; integrate into a CubeMX-generated project.
   Not a complete flashable board project. See docs/HARDWARE.md. */
#include "FreeRTOS.h"
#include "app_runtime.h"
#include "board_port.h"
#include "stm32f4xx_hal.h"
#include "task.h"
#include <math.h>
#include <string.h>
extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart2;
extern TIM_HandleTypeDef htim2;
/* CH1 PA0 PWM, 1MHz counter, 32bit */
extern TIM_HandleTypeDef htim5;
/* 1MHz free-running, ARR=0xffffffff */
static uint8_t tx_buffer[VOFA_FRAME_BYTES], rx_byte;
static volatile int tx_busy;
static int read_reg(void *ctx, uint8_t a, uint8_t r, uint8_t *b, size_t n) {
    (void)ctx;
    return HAL_I2C_Mem_Read(&hi2c1, (uint16_t)(a << 1), r, I2C_MEMADD_SIZE_8BIT, b, (uint16_t)n,
                            2) == HAL_OK
               ? 0
               : -1;
}
static int write_reg(void *ctx, uint8_t a, uint8_t r, uint8_t v) {
    (void)ctx;
    return HAL_I2C_Mem_Write(&hi2c1, (uint16_t)(a << 1), r, I2C_MEMADD_SIZE_8BIT, &v, 1, 2) ==
                   HAL_OK
               ? 0
               : -1;
}
static void delay_ms(void *ctx, unsigned ms) {
    (void)ctx;
    vTaskDelay(pdMS_TO_TICKS(ms));
}
Mpu6050 BoardMpu6050(void) {
    Mpu6050 m = {NULL, read_reg, write_reg, delay_ms, 0x68};
    return m;
}
uint32_t BoardMicros(void) {
    return __HAL_TIM_GET_COUNTER(&htim5);
}
void BoardUartStartRx(void) {
    if (HAL_UART_Receive_IT(&huart2, &rx_byte, 1) != HAL_OK)
        AppRxErrorFromISR();
}
int BoardUartTrySend(const uint8_t *p, size_t n) {
    if (n > sizeof(tx_buffer))
        return -1;
    taskENTER_CRITICAL();
    if (tx_busy) {
        taskEXIT_CRITICAL();
        return -1;
    }
    tx_busy = 1;
    taskEXIT_CRITICAL();
    memcpy(tx_buffer, p, n);
    if (HAL_UART_Transmit_DMA(&huart2, tx_buffer, (uint16_t)n) != HAL_OK) {
        tx_busy = 0;
        return -1;
    }
    return 0;
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *h) {
    if (h == &huart2)
        tx_busy = 0;
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *h) {
    if (h == &huart2) {
        AppRxByteFromISR(rx_byte);
        if (HAL_UART_Receive_IT(h, &rx_byte, 1) != HAL_OK)
            AppRxErrorFromISR();
    }
}
void HAL_UART_ErrorCallback(UART_HandleTypeDef *h) {
    if (h == &huart2) {
        AppRxErrorFromISR();
        /* Abort TX DMA before releasing its owned buffer. Error context is ISR. */
        HAL_UART_AbortTransmit(h);
        tx_busy = 0;
        HAL_UART_AbortReceive(h);
        if (HAL_UART_Receive_IT(h, &rx_byte, 1) != HAL_OK)
            AppRxErrorFromISR();
    }
}
static void force_low(void) {
    HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
    GPIO_InitTypeDef pin = {0};
    pin.Pin = GPIO_PIN_0;
    pin.Mode = GPIO_MODE_OUTPUT_PP;
    pin.Pull = GPIO_NOPULL;
    pin.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &pin);
}
int BoardPwm(void *unused, float hz, float duty) {
    (void)unused;
    if (duty == 0) {
        force_low();
        return 0;
    }
    if (!isfinite(hz) || !isfinite(duty) || hz < .5f || hz > 20 || duty <= 0 || duty > .1f) {
        force_low();
        return -1;
    }
    const double counter_hz = 1000000.0;
    /* Must match CubeMX TIM2 settings. */
    uint32_t ticks = (uint32_t)llround(counter_hz / hz),
             on = (uint32_t)llround(ticks * (double)duty);
    if (!on || on >= ticks) {
        force_low();
        return -1;
    }
    HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
    __HAL_TIM_SET_AUTORELOAD(&htim2, ticks - 1);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, on);
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    HAL_TIM_GenerateEvent(&htim2, TIM_EVENTSOURCE_UPDATE);
    GPIO_InitTypeDef pin = {0};
    pin.Pin = GPIO_PIN_0;
    pin.Mode = GPIO_MODE_AF_PP;
    pin.Pull = GPIO_NOPULL;
    pin.Speed = GPIO_SPEED_FREQ_LOW;
    pin.Alternate = GPIO_AF1_TIM2;
    HAL_GPIO_Init(GPIOA, &pin);
    if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1) != HAL_OK) {
        force_low();
        return -1;
    }
    return 0;
}
