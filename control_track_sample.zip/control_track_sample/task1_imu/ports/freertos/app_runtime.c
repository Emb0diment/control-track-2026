#include "app_runtime.h"
#include "FreeRTOS.h"
#include "app_config.h"
#include "board_port.h"
#include "calibration_board.h"
#include "imu_service.h"
#include "queue.h"
#include "task.h"
#include <math.h>
#include <string.h>
typedef struct {
    float ch[VOFA_CHANNELS];
} Snapshot;
typedef struct {
    float ack, hz, duty;
} CommandStatus;
static QueueHandle_t snapshots, rx, command_status;
static StaticQueue_t snap_cb, rx_cb, command_cb;
static uint8_t snap_store[sizeof(Snapshot)], rx_store[APP_RX_QUEUE_LENGTH],
    command_store[sizeof(CommandStatus)];
static StaticTask_t imu_cb, vofa_cb, control_cb;
static StackType_t imu_stack[APP_IMU_STACK_WORDS], vofa_stack[APP_TELEMETRY_STACK_WORDS],
    control_stack[APP_COMMAND_STACK_WORDS];
static volatile uint32_t rx_errors;
static uint32_t rx_error_count(void) {
    uint32_t n;
    taskENTER_CRITICAL();
    n = rx_errors;
    taskEXIT_CRITICAL();
    return n;
}
void AppRxByteFromISR(uint8_t byte) {
    BaseType_t wake = pdFALSE;
    if (xQueueSendFromISR(rx, &byte, &wake) != pdPASS)
        rx_errors++;
    portYIELD_FROM_ISR(wake);
}
void AppRxErrorFromISR(void) {
    rx_errors++;
}
static void ImuTask(void *unused) {
    (void)unused;
    Mpu6050 m = BoardMpu6050();
    ImuService service;
    ImuServiceInit(&service, &kCalibration, IMU_CALIBRATION_VALID);
    int device_ok = Mpu6050Init(&m) == 0;
    uint32_t retry_us = BoardMicros();
    TickType_t next = xTaskGetTickCount();
    for (;;) {
        uint32_t start = BoardMicros();
        ImuSample sample = {0};
        int rc = -1;
        if (!device_ok && (uint32_t)(start - retry_us) >= 1000000) {
            device_ok = Mpu6050Init(&m) == 0;
            retry_us = BoardMicros();
            next = xTaskGetTickCount();
            start = BoardMicros();
        }
        if (device_ok)
            rc = Mpu6050Read(&m, &sample, start);
        ImuServiceStep(&service, &sample, rc);
        if (device_ok && service.failures >= 5) {
            device_ok = 0;
            retry_us = start;
        }
        Snapshot v = {{0}};
        v.ch[0] = service.raw.stamp_us * 1e-6f;
        for (int i = 0; i < 3; i++) {
            v.ch[1 + i] = service.raw.a[i];
            v.ch[4 + i] = service.raw.w[i];
            v.ch[7 + i] = service.calibrated.a[i];
            v.ch[10 + i] = service.calibrated.w[i];
            v.ch[13 + i] = service.rpy[i];
            v.ch[16 + i] = service.total_bias[i];
        }
        v.ch[19] = service.dt;
        v.ch[20] = service.qnorm;
        v.ch[21] = (float)service.status;
        v.ch[22] = (float)service.sequence;
        v.ch[23] = (float)(uint32_t)(BoardMicros() - start);
        v.ch[24] = service.dt * 1e6f - APP_IMU_PERIOD_MS * 1000;
        v.ch[25] = (float)uxTaskGetStackHighWaterMark(NULL);
        v.ch[27] = (float)service.read_errors;
        xQueueOverwrite(snapshots, &v);
        vTaskDelayUntil(&next, pdMS_TO_TICKS(APP_IMU_PERIOD_MS));
    }
}
static void VofaTask(void *unused) {
    (void)unused;
    TickType_t next = xTaskGetTickCount();
    uint32_t last = 0, skipped = 0;
    uint8_t frame[VOFA_FRAME_BYTES];
    for (;;) {
        Snapshot v;
        if (xQueueReceive(snapshots, &v, 0) == pdPASS) {
            uint32_t seq = (uint32_t)v.ch[22];
            if (last && seq > last + 1)
                skipped += seq - last - 1;
            last = seq;
            v.ch[26] = (float)skipped;
            v.ch[28] = (float)rx_error_count();
            CommandStatus st;
            if (xQueuePeek(command_status, &st, 0) == pdPASS) {
                v.ch[29] = st.ack;
                v.ch[30] = st.hz;
                v.ch[31] = st.duty;
            }
            VofaEncode(v.ch, frame);
            if (BoardUartTrySend(frame, sizeof(frame)))
                skipped++;
        }
        vTaskDelayUntil(&next, pdMS_TO_TICKS(APP_TELEMETRY_PERIOD_MS));
    }
}
static void CommandTask(void *unused) {
    (void)unused;
    Strobe s;
    StrobeInit(&s, BoardPwm, NULL);
    BoardUartStartRx();
    uint32_t prev_errors = 0;
    TickType_t next = xTaskGetTickCount();
    for (;;) {
        uint32_t now = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS),
                 errors = rx_error_count();
        if (errors != prev_errors) {
            StrobeEmergencyOff(&s, STROBE_ERR_OVERFLOW);
            s.used = 0;
            s.discard = 1;
            prev_errors = errors;
        }
        uint8_t c;
        for (int k = 0; k < 64 && xQueueReceive(rx, &c, 0) == pdPASS; k++)
            StrobeFeed(&s, (char)c, now);
        StrobePoll(&s, now);
        CommandStatus v = {(float)s.ack, s.hz, s.duty};
        xQueueOverwrite(command_status, &v);
        vTaskDelayUntil(&next, pdMS_TO_TICKS(APP_COMMAND_PERIOD_MS));
    }
}
void AppStart(void) {
    configASSERT(pdMS_TO_TICKS(APP_IMU_PERIOD_MS) > 0);
    snapshots = xQueueCreateStatic(1, sizeof(Snapshot), snap_store, &snap_cb);
    rx = xQueueCreateStatic(APP_RX_QUEUE_LENGTH, 1, rx_store, &rx_cb);
    command_status = xQueueCreateStatic(1, sizeof(CommandStatus), command_store, &command_cb);
    configASSERT(snapshots && rx && command_status);
    TaskHandle_t a =
        xTaskCreateStatic(ImuTask, "ImuEkf", APP_IMU_STACK_WORDS, NULL, 3, imu_stack, &imu_cb);
    TaskHandle_t b = xTaskCreateStatic(CommandTask, "Command", APP_COMMAND_STACK_WORDS, NULL, 2,
                                       control_stack, &control_cb);
    TaskHandle_t c = xTaskCreateStatic(VofaTask, "Vofa", APP_TELEMETRY_STACK_WORDS, NULL, 1,
                                       vofa_stack, &vofa_cb);
    configASSERT(a && b && c);
    (void)a;
    (void)b;
    (void)c;
}
