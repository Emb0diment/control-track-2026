# 应用架构与分层

原则：算法不知道传感器寄存器；驱动不知道滤波器；业务不知道 HAL；RTOS 只负责调度和传递完整快照。

## 分层职责

| 层 | 文件夹 | 输入/输出 | 依赖边界 |
|---|---|---|---|
| 算法核心 | core/ | SI 六轴数据、dt → 姿态、零偏、协方差 | C 标准库、数学库、数值配置 |
| 设备驱动 | drivers/ | 寄存器访问回调 → SI 原始采样 | peripherals.h 回调，无 HAL |
| 协议 | protocol/ | 32 个 float → JustFloat 帧 | 纯 C，无串口或 RTOS |
| 应用服务 | app/ | 采样结果 → 初始化/运行/掉线状态；字节 → 频闪状态 | 算法 API、PWM 回调 |
| 调度适配 | ports/freertos/ | 周期与中断事件 → 调用应用服务、排队发送 | FreeRTOS、board_port.h |
| 板级适配 | ports/stm32f4/ | I²C/UART/定时器 API → 真硬件 | STM32 HAL，少量 RTOS 适配 |
| 电脑工具 | host/、tools/ | CSV → 同一 C 算法 → CSV/曲线 | host C + Python 图表 |
| 配置 | config/ | 标定、噪声、任务周期 | 不包含业务逻辑 |

```mermaid
flowchart TD
  Host[电脑回放入口] --> Core[C 标定与 ESKF]
  Tasks[FreeRTOS 调度] --> Service[IMU 应用服务]
  Service --> Core
  Tasks --> Driver[MPU6050 驱动]
  Driver --> Board[板级适配]
  Tasks --> Proto[遥测协议]
  Tasks --> Led[频闪服务]
  Led --> Board
  Proto --> DMA[发送缓冲]
  DMA --> Board
```

## 两条运行路径

电脑路径：run_demo.py 编译 → imu_cli calibrate → imu_cli replay → Python 绘图。Python 不计算 EKF。
硬件路径：I²C 采样 → ImuServiceStep → 长度 1 的姿态快照队列 → VofaTask → 持久 DMA 缓冲 → 串口。

电脑回放用于算法复核，实际硬件验收仍需要板端实时运行。默认板端遥测为 50 Hz，算法目标为 200 Hz，因此遥测回放只是在降采样日志上重新计算，不应声称与板端每一步数值相同。需精确回放时，按硬件说明提高串口带宽和记录频率，或使用板载存储记录每次更新。

## 状态和所有权

- ImuTask 独占 ImuService，其中含滤波器、标定、初始化统计和计数器。
- VofaTask 只接收完整值拷贝；不会直接读写滤波器对象。
- CommandTask 独占 Strobe。接收中断仅把字节放入队列，不做浮点解析和 PWM 运算。
- 频闪状态通过另一长度 1 的队列传给遥测。
- UART DMA 缓冲由板级发送适配器独占，发送完成前不能复写。
- 唯一跨 ISR/任务的错误计数为对齐 uint32，任务读时临界区保护；队列 API 遵守中断优先级要求。

## 应用状态转换

```mermaid
stateDiagram-v2
  [*] --> 待标定
  待标定 --> 静止初始化: 载入真实标定后重新启动
  静止初始化 --> 正常运行: 连续100个合格样本
  正常运行 --> 静止初始化: 时间间隔或数值异常
  正常运行 --> 离线: 连续5次无有效样本
  静止初始化 --> 离线: 连续5次无有效样本
  离线 --> 静止初始化: 重连并恢复采样
```

没有标定时只采集原始数据；启动/重连后必须静止约 0.5 s。运动或方差过大就清空初始化窗口重新收集。一次数据异常不做姿态外推；连续异常离线，驱动按约 1 s 重试。离线姿态保留最后值，但状态位明确标记无效。

## 错误分工

驱动只返回“成功 / 无新样本 / 总线失败”；应用决定是否离线；调度决定何时重试；VOFA 显示状态。算法拒绝无效 dt 或非有限数，不修改原状态；应用随后要求重新静止初始化。

## 可扩展点

- 多 IMU：分别创建 ImuService 实例，禁止共享一个滤波器对象。
- 其他通讯：保留 Snapshot，替换 VofaEncode 和 BoardUartTrySend。
- 零偏冻结：在拥有滤波器的任务中设置 `service.ekf.freeze_bias=1`；恢复为 0。不要从另一个任务无保护写入。
- 磁力计：新增磁测量驱动、标定与观测模型，不能仅给 yaw 叠加一个未经标定的角度。六轴版保留 yaw 漂移限制。
