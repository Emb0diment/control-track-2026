# 硬件接入与真实数据流程

## 先确定适配边界

本包提供 STM32F4 HAL 示例，参考 STM32F401CC 类开发板；你尚未提供实际板卡。因此没有经过验证的 .ioc、启动文件、链接脚本或烧录文件。
请用你实际芯片对应的 STM32CubeMX/IDE 生成底层工程，将本包 C 文件加入工程。以下引脚只是参考映射，需要核对你的板卡原理图和芯片复用表。
不要把 tests/rtos_stubs 加入固件，它们只用于电脑语法检查。

## 示例接线

| 功能 | 示例资源 | 接线说明 |
|---|---|---|
| MPU6050 SCL/SDA | I2C1 PB6/PB7 | 3.3 V 逻辑，合适上拉，短线，共地 |
| MPU6050 电源 | 3.3 V、GND | 确认所用模块供电规格；AD0 接地选择 0x68 |
| PC 串口 | USART2 PA2 TX / PA3 RX | TX 接 USB 串口 RX，RX 接 TX，共地，3.3 V 电平 |
| 微秒计时 | TIM5 | 内部时钟，1 MHz，ARR=0xffffffff，无需引脚 |
| 低功率 LED | TIM2_CH1 PA0 | 示例外接限流指示 LED；不用高功率光源 |

优先使用板载指示灯；若板载灯不在可用 PWM 引脚上，需要调整板级适配或另接低功率指示 LED。PA0 示例假定高电平点亮；反相电路必须对应修改默认关闭逻辑。

## CubeMX 配置清单

- I2C1：400 kHz，7 位地址，示例适配器单次 HAL 访问超时 2 ms。驱动接口传 7 位地址；HAL 适配层才左移一位。
- USART2：115200、8N1，TX DMA Normal 模式，RX 中断；启用 UART 和相应 DMA 中断。
- TIM5：实际计数频率 1 MHz，32 位 ARR 最大值；main 中启动 Base 计时。
- TIM2：实际计数频率 1 MHz，CH1 PWM Mode 1、高有效；不要把该计时器同时用于其他功能。
- 例如 TIM 时钟为 84 MHz 时 PSC=83；若你的 APB 时钟不同，必须重新计算，不可直接照抄。APB 分频可能引入定时器倍频。
- FreeRTOS tick 建议 1000 Hz，支持静态分配，启用栈水位、DelayUntil、栈溢出检查及 configASSERT；configMAX_PRIORITIES 至少 4。
- 使用原生 FreeRTOS API。若 CubeMX 生成 CMSIS-RTOS 外壳，保留一种启动路径，避免重复启动调度器或重复创建任务。
- UART 中断使用 FromISR API，NVIC 优先级必须满足 configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY 限制；数值过小的高优先级不可调用内核 API。
- 提供 FreeRTOS 静态 Idle/Timer 任务内存回调（按你的内核配置）；HAL 时基建议独立于 RTOS SysTick 的定时器。
- 检查 GPIO 时钟、DMA IRQHandler、USART IRQHandler 和 HAL 回调连接是否完整。

固件需编译：core/*.c、drivers/*.c、protocol/*.c、app/*.c、ports/freertos/app_runtime.c、ports/stm32f4/board_port_stm32f4.c。
头文件路径：include/、config/、真实 FreeRTOS 与 STM32 HAL 目录。C11、数学库、硬浮点 ABI 必须与整个工程一致。

main 在初始化全部外设后、启动调度器前，做如下接入（示意，不替换整个 main）：

```c
HAL_TIM_Base_Start(&htim5);
BoardPwm(NULL, 0, 0);   /* 默认关闭 */
AppStart();
vTaskStartScheduler();
```

应先检查 HAL 初始化返回值。若使用已有 UART 回调，把本包回调内容合并进去，不能定义两份同名回调。启动前外设引脚也应处于关闭状态。

## MPU6050 参数表

| 项目 | 寄存器/值 | 解释 |
|---|---|---|
| 地址 | 0x68 | AD0=0；AD0=1 可改成 0x69 |
| WHO_AM_I | 0x75 → 0x68 | 识别检查 |
| PWR_MGMT_1 | 0x6B → 0x01 | 复位后唤醒，X gyro PLL |
| PWR_MGMT_2 | 0x6C → 0x00 | 六轴启用 |
| CONFIG | 0x1A → 0x03 | DLPF=3；加速度约 44 Hz、陀螺仪约 42 Hz |
| SMPLRT_DIV | 0x19 → 0x04 | DLPF 开启时 1 kHz/(1+4)=200 Hz |
| GYRO_CONFIG | 0x1B → 0x08 | ±500 deg/s；65.5 LSB/(deg/s)，再转 rad/s |
| ACCEL_CONFIG | 0x1C → 0x08 | ±4g；8192 LSB/g，再乘 9.80665 |
| INT_ENABLE | 0x38 → 0x01 | 开启数据就绪状态；本样例轮询 INT_STATUS |
| 数据 | 从 0x3B 读 14 字节 | 三轴 accel、温度、三轴 gyro；温度暂不使用 |

来源：TDK/InvenSense MPU-6000/MPU-6050 Register Map。驱动写入后回读上述配置，任何不一致判失败。模块坐标轴和实际安装方向仍需你核对。
这是 MCU 读取时刻的时间戳近似，不是数据就绪中断精确采样时刻；高动态精度要求更高时，应接入 DRDY 时间戳或 FIFO。不能据此声称采样完全无抖动。

## 任务设置与带宽

| 任务 | 名义周期 | 优先级 | 示例栈大小 | 责任 |
|---|---:|---:|---:|---|
| ImuTask | 5 ms | 3 | 2048 words | 读传感器、应用状态、标定、EKF |
| CommandTask | 10 ms | 2 | 512 words | 接收队列、命令解析、PWM、超时 |
| VofaTask | 20 ms | 1 | 512 words | 拿最新快照、编码、尝试 DMA 发送 |

栈单位是 StackType_t 个数，Cortex-M 常为 4 字节，不是字节数。配置值只是起点，必须在目标板测栈水位。当前遥测记录的是 IMU 任务的最低历史剩余栈；调试时也应检查另外两个任务。
32 通道 JustFloat 每帧 132 字节，50 Hz 为 6600 B/s；115200、8N1 理论有效上限 11520 B/s。200 Hz 输出需 26400 B/s，建议至少 460800 波特并验证余量。
读取采用有界阻塞 I²C；UART 则为 DMA 非阻塞。若 I²C 超时导致超周期，dt 检查与状态机负责拒绝异常，而不是用名义 5 ms 继续积分。
exec_us 记录读数与算法段，不含之后的栈水位查询、队列投递；完整周期需配合示波器/trace 或在目标板扩展测量。
快照队列有意保留最新值；skipped 统计降频跳过与发送失败累计，不应误解为传感器硬件丢样的准确数量。read_errors 包含“无新样本”，不能当成纯 I²C 故障次数。

## 第一次真实运行：先采集，再标定

1. 保持 config/calibration_board.h 中有效标志为 0，编译烧录。确认 VOFA 原始加速度模长约为 g、陀螺仪静止近零、状态有 CAL_REQUIRED。
2. 关闭 VOFA（避免串口占用），每个面固定不动约 10 秒。例如 +X 朝上：

```bash
python tools/capture.py --port COM5 --face 0 --seconds 10 --output data/real_px.csv
```

依次用 face=1..5 采集 real_nx、real_py、real_ny、real_pz、real_nz。正轴朝上应测得该轴正 g，先核对符号。

3. 合并并生成标定：

```bash
python tools/combine_faces.py data/real_px.csv data/real_nx.csv data/real_py.csv data/real_ny.csv data/real_pz.csv data/real_nz.csv --output data/real_faces.csv
build/imu_cli calibrate data/real_faces.csv results/real_calibration.txt
```

Windows 对应可执行文件为 build/imu_cli.exe。

4. 把 `results/real_calibration.txt.h` 复制成 `config/calibration_board.h`，检查参数合理、有效标志为 1，再编译烧录。不要复制 SYNTHETIC 标定。
5. 开机保持静止至少 1 秒，观察 INITIALIZING 清除、qnorm 约为 1，之后轻缓改变 roll/pitch 并穿插静止。
6. 采集动态日志：

```bash
python tools/capture.py --port COM5 --seconds 30 --output data/real_dynamic.csv
build/imu_cli replay data/real_dynamic.csv results/real_calibration.txt results/real_replay.csv
python tools/plot_replay.py results/real_replay.csv --out results/real_plots
```

电脑 replay 要求日志开头至少 100 个静止样本（默认 50 Hz 遥测约需 2 秒），建议前 3 秒保持静止。这和板端 200 Hz 初始化 0.5 秒不同。
保留 .telemetry.csv：其中姿态才是板端实际输出；real_replay.csv 是主机用降采样原始日志重新计算的结果，不能替代板端曲线。
可直接用 VOFA 或表格软件画 .telemetry.csv 中的 roll/pitch；其列名和单位已写入表头。

## 故障排查

| 现象 | 先检查 |
|---|---|
| 一直 OFFLINE | 供电、共地、地址、上拉、WHO_AM_I、寄存器回读 |
| 一直 INITIALIZING | 是否静止、标定是否来自当前传感器、坐标映射 |
| 角度方向相反 | 加速度和角速度是否使用相同右手轴映射 |
| BAD_DT 频繁 | 微秒计时频率、I²C 超时、任务调度、其他高优先级任务 |
| VOFA 乱码 | 选择 JustFloat，不把二进制当文本；32 通道、115200 |
| LED 不亮 | PWM 引脚与计时器映射、极性、串口命令换行、2 秒超时 |
| 串口不再发送 | DMA 完成 IRQ/回调、USART IRQ、错误回调是否合并 |

## 官方资料

- TDK 产品/文档入口：https://product.tdk.com/en/search/sensor/mortion-inertial/imu/info?part_no=MPU-6050
- MPU 寄存器文档入口：https://invensense.tdk.com/wp-content/uploads/2015/02/MPU-6000-Register-Map1.pdf （旧链接可能重定向，必要时从产品页获取）
- STM32F401 RM0368：https://www.st.com/resource/en/reference_manual/rm0368-stm32f401xbc-and-stm32f401xde-advanced-armbased-32bit-mcus-stmicroelectronics.pdf
- FreeRTOS API：https://www.freertos.org/Documentation/02-Kernel/04-API-references/03-Task-utilities/00-Task-utilities
