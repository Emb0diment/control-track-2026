#include "imu.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int loadcal(const char *path, ImuCalibration *c) {
    FILE *f = fopen(path, "r");
    if (!f)
        return -1;
    float v[9];
    int ok = 1;
    for (int i = 0; i < 9; i++)
        if (fscanf(f, "%f", &v[i]) != 1 || !isfinite(v[i]))
            ok = 0;
    fclose(f);
    if (!ok)
        return -1;
    for (int i = 0; i < 3; i++) {
        c->offset[i] = v[i];
        c->scale[i] = v[i + 3];
        c->gyro_bias[i] = v[i + 6];
        if (c->scale[i] < 0.5f || c->scale[i] > 2 || fabsf(c->gyro_bias[i]) > 0.2f)
            return -1;
    }
    return 0;
}
static int calibrate(const char *input, const char *output) {
    FILE *f = fopen(input, "r");
    if (!f)
        return 1;
    char line[512];
    ImuStats faces[6] = {{0}};
    if (!fgets(line, sizeof(line), f)) {
        fclose(f);
        return 2;
    }
    while (fgets(line, sizeof(line), f)) {
        int face, n = 0;
        double t;
        ImuSample s = {0};
        int got = sscanf(line, "%d,%lf,%f,%f,%f,%f,%f,%f %n", &face, &t, &s.a[0], &s.a[1], &s.a[2],
                         &s.w[0], &s.w[1], &s.w[2], &n);
        if (got != 8 || line[n] != '\0' || face < 0 || face > 5 || !isfinite(t)) {
            fclose(f);
            return 3;
        }
        for (int i = 0; i < 3; i++)
            if (!isfinite(s.a[i]) || !isfinite(s.w[i])) {
                fclose(f);
                return 3;
            }
        ImuStatsPush(&faces[face], &s);
    }
    fclose(f);
    ImuCalibration c;
    int rc = ImuCalibrate(faces, &c);
    if (rc) {
        fprintf(stderr, "Calibration quality failed: %d\n", rc);
        return 4;
    }
    f = fopen(output, "w");
    if (!f)
        return 5;
    for (int i = 0; i < 3; i++)
        fprintf(f, "%.9g ", c.offset[i]);
    fprintf(f, "\n");
    for (int i = 0; i < 3; i++)
        fprintf(f, "%.9g ", c.scale[i]);
    fprintf(f, "\n");
    for (int i = 0; i < 3; i++)
        fprintf(f, "%.9g ", c.gyro_bias[i]);
    fprintf(f, "\n");
    fclose(f);
    char hpath[1024];
    if (snprintf(hpath, sizeof(hpath), "%s.h", output) >= (int)sizeof(hpath))
        return 6;
    f = fopen(hpath, "w");
    if (!f)
        return 6;
    fprintf(f,
            "/* Generated from input data: verify these are YOUR real sensor samples. */\n#ifndef "
            "CALIBRATION_BOARD_H\n#define CALIBRATION_BOARD_H\n#include \"imu.h\"\n#define "
            "IMU_CALIBRATION_VALID %d\nstatic const ImuCalibration kCalibration={\n{",
            strstr(input, "SYNTHETIC") == NULL ? 1 : 0);
    for (int i = 0; i < 3; i++)
        fprintf(f, "%s%.9ef", i ? "," : "", (double)c.offset[i]);
    fprintf(f, "},{");
    for (int i = 0; i < 3; i++)
        fprintf(f, "%s%.9ef", i ? "," : "", (double)c.scale[i]);
    fprintf(f, "},{");
    for (int i = 0; i < 3; i++)
        fprintf(f, "%s%.9ef", i ? "," : "", (double)c.gyro_bias[i]);
    fprintf(f, "}};\n#endif\n");
    fclose(f);
    puts("Calibration saved. Synthetic calibration must never be used on hardware.");
    return 0;
}
static int replay(const char *input, const char *cal, const char *output) {
    ImuCalibration c;
    if (loadcal(cal, &c))
        return 1;
    FILE *f = fopen(input, "r");
    if (!f)
        return 2;
    FILE *o = fopen(output, "w");
    if (!o) {
        fclose(f);
        return 2;
    }
    char line[1024];
    ImuEkf e;
    ImuStats init = {0};
    float qgyro[4] = {1, 0, 0, 0};
    double last = -1;
    int ready = 0, rc = 0;
    unsigned rows = 0;
    if (!fgets(line, sizeof(line), f)) {
        rc = 3;
        goto done;
    }
    fprintf(o, "timestamp_s,raw_ax,raw_ay,raw_az,raw_gx,raw_gy,raw_gz,cal_ax,cal_ay,cal_az,cal_gx,"
               "cal_gy,cal_gz,acc_roll,acc_pitch,gyro_roll,gyro_pitch,gyro_yaw,ekf_roll,ekf_pitch,"
               "ekf_yaw,bias_x,bias_y,bias_z,qnorm,status\n");
    while (fgets(line, sizeof(line), f)) {
        ImuSample raw = {0}, s;
        double t;
        int used = 0;
        int n = sscanf(line, "%lf,%f,%f,%f,%f,%f,%f %n", &t, &raw.a[0], &raw.a[1], &raw.a[2],
                       &raw.w[0], &raw.w[1], &raw.w[2], &used);
        if (n != 7 || line[used] != '\0' || !isfinite(t) || t < 0 || (last >= 0 && t <= last)) {
            rc = 4;
            break;
        }
        for (int i = 0; i < 3; i++)
            if (!isfinite(raw.a[i]) || !isfinite(raw.w[i]))
                rc = 4;
        if (rc)
            break;
        float dt = last < 0 ? 0 : (float)(t - last);
        last = t;
        ImuApplyCalibration(&c, &raw, &s);
        if (!ready) {
            ImuStatsPush(&init, &s);
            if (init.n < 100)
                continue;
            float a[3];
            for (int i = 0; i < 3; i++) {
                a[i] = (float)init.mean[i];
                if (sqrt(init.m2[i] / 99) > 0.15 || sqrt(init.m2[i + 3] / 99) > 0.02 ||
                    fabs(init.mean[i + 3]) > 0.08)
                    rc = 5;
            }
            if (rc || ImuEkfInit(&e, a, NULL)) {
                rc = 5;
                break;
            }
            memcpy(qgyro, e.q, sizeof(qgyro));
            ready = 1;
            continue;
        }
        int status = ImuEkfUpdate(&e, s.w, s.a, dt);
        if (status < 0) {
            rc = 6;
            break;
        }
        ImuQuatStep(qgyro, s.w, dt);
        float eg[3], ee[3];
        ImuEulerFromQuat(qgyro, eg);
        ImuEkfGetEuler(&e, ee);
        float ar = atan2f(s.a[1], s.a[2]), ap = atan2f(-s.a[0], hypotf(s.a[1], s.a[2]));
        float qn = 0;
        for (int i = 0; i < 4; i++)
            qn += e.q[i] * e.q[i];
        qn = sqrtf(qn);
        fprintf(o, "%.9f", t);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", raw.a[i]);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", raw.w[i]);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", s.a[i]);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", s.w[i]);
        fprintf(o, ",%.9g,%.9g", ar, ap);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", eg[i]);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", ee[i]);
        for (int i = 0; i < 3; i++)
            fprintf(o, ",%.9g", c.gyro_bias[i] + e.bias[i]);
        fprintf(o, ",%.9g,%d\n", qn, status);
        rows++;
    }
    if (!rows && !rc)
        rc = 7;
done:
    fclose(f);
    fclose(o);
    if (rc)
        fprintf(stderr, "Replay failed: %d (check stationary startup, units, timestamps)\n", rc);
    return rc;
}
int main(int argc, char **argv) {
    if (argc == 4 && strcmp(argv[1], "calibrate") == 0)
        return calibrate(argv[2], argv[3]);
    if (argc == 5 && strcmp(argv[1], "replay") == 0)
        return replay(argv[2], argv[3], argv[4]);
    fprintf(stderr, "Usage: imu_cli calibrate faces.csv calibration.txt\n       imu_cli replay "
                    "dynamic.csv calibration.txt output.csv\n");
    return 1;
}
