#ifndef IMU_H
#define IMU_H
#include <stddef.h>
#include <stdint.h>
#define IMU_G 9.80665f
#define IMU_PI 3.14159265358979323846f
/* Sensor axes are body axes. World is ENU-like z-up. q rotates body to world,
   scalar first, Hamilton product. At rest accelerometer measures +world z. */
typedef struct {
    float a[3], w[3];
    uint32_t stamp_us;
} ImuSample;
typedef struct {
    float offset[3], scale[3], gyro_bias[3];
} ImuCalibration;
typedef struct {
    unsigned n;
    double mean[6], m2[6];
} ImuStats;
void ImuStatsPush(ImuStats *s, const ImuSample *v);
void ImuCalibrationIdentity(ImuCalibration *c);
/* faces: +X,-X,+Y,-Y,+Z,-Z; all values in SI, >=100 stationary samples/face. */
int ImuCalibrate(const ImuStats faces[6], ImuCalibration *out);
void ImuApplyCalibration(const ImuCalibration *c, const ImuSample *in, ImuSample *out);
typedef struct {
    float gyro_noise, bias_rw, accel_direction_sigma, accel_gate;
    float dt_min, dt_max;
} ImuEkfConfig;
typedef struct {
    float q[4], bias[3], P[6][6];
    ImuEkfConfig cfg;
    unsigned accepted, rejected;
    int freeze_bias;
} ImuEkf;
enum { IMU_EKF_OK = 0, IMU_EKF_ACCEL_SKIPPED = 1, IMU_EKF_BAD_INPUT = -1, IMU_EKF_NUMERIC = -2 };
ImuEkfConfig ImuEkfDefaultConfig(void);
/* accel in m/s^2. Caller ensures stationary for initialization. yaw starts at zero. */
int ImuEkfInit(ImuEkf *e, const float accel[3], const ImuEkfConfig *cfg);
/* gyro in rad/s after static bias removal; bias here is residual ONLY.
   dt in seconds. No allocation, no runtime dependencies besides libc/libm. */
int ImuEkfUpdate(ImuEkf *e, const float gyro[3], const float accel[3], float dt_s);
void ImuEkfGetEuler(const ImuEkf *e, float rpy_rad[3]);
void ImuQuatStep(float q[4], const float w[3], float dt_s);
void ImuGravityBody(const float q[4], float h[3]);
void ImuEulerFromQuat(const float q[4], float rpy[3]);
#endif
