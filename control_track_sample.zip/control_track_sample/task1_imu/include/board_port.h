#ifndef BOARD_PORT_H
#define BOARD_PORT_H
#include "peripherals.h"
/* All target/HAL details belong behind this interface. Called in task context
   except AppRxByteFromISR/AppRxErrorFromISR declared in app_runtime.h. */
Mpu6050 BoardMpu6050(void);
uint32_t BoardMicros(void); /* free-running 1MHz uint32, wrap allowed */
void BoardUartStartRx(void);
/* Must copy data into DMA-owned persistent storage before returning; 0 success. */
int BoardUartTrySend(const uint8_t *data, size_t size);
int BoardPwm(void *unused, float hz, float duty);
#endif
