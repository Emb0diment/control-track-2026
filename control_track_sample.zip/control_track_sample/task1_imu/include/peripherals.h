#ifndef PERIPHERALS_H
#define PERIPHERALS_H
#include "imu.h"
typedef struct {
    void *ctx;
    int (*read)(void *, uint8_t addr7, uint8_t reg, uint8_t *buf, size_t n);
    int (*write)(void *, uint8_t addr7, uint8_t reg, uint8_t value);
    void (*delay_ms)(void *, unsigned ms);
    uint8_t addr7;
} Mpu6050;
int Mpu6050Init(Mpu6050 *m);
/* 0 sample OK, 1 no fresh sample, negative bus/config error. */
int Mpu6050Read(Mpu6050 *m, ImuSample *v, uint32_t timestamp_us);
enum {
    STROBE_ACK_NONE = 0,
    STROBE_ACK_ON = 1,
    STROBE_ACK_OFF = 2,
    STROBE_ERR_COMMAND = -1,
    STROBE_ERR_RANGE = -2,
    STROBE_ERR_OVERFLOW = -3,
    STROBE_ERR_TIMEOUT = -4,
    STROBE_ERR_HARDWARE = -5,
    STROBE_ERR_DURATION = -6
};
typedef struct {
    char line[48];
    size_t used;
    int discard, on, ack, lockout;
    float hz, duty;
    uint32_t last_valid_ms, start_ms, last_byte_ms;
    void *ctx;
    int (*pwm)(void *, float hz, float duty); /* duty=0 must force LOW */
} Strobe;
void StrobeInit(Strobe *s, int (*pwm)(void *, float, float), void *ctx);
void StrobeFeed(Strobe *s, char c, uint32_t now_ms);
void StrobePoll(Strobe *s, uint32_t now_ms);
void StrobeEmergencyOff(Strobe *s, int reason);
#define VOFA_CHANNELS 32
#define VOFA_FRAME_BYTES (4 * (VOFA_CHANNELS + 1))
size_t VofaEncode(const float channels[VOFA_CHANNELS], uint8_t dst[VOFA_FRAME_BYTES]);
#endif
