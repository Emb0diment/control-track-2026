#ifndef IMU_SERVICE_H
#define IMU_SERVICE_H
#include "imu.h"
enum {
    IMU_CAL_REQUIRED = 1,
    IMU_INITIALIZING = 2,
    IMU_OFFLINE = 4,
    IMU_ACCEL_REJECTED = 8,
    IMU_BAD_DT = 16,
    IMU_NUMERIC_FAULT = 32,
    IMU_STALE = 64
};
typedef struct {
    ImuCalibration cal;
    ImuEkf ekf;
    ImuStats startup;
    ImuSample raw, calibrated;
    float rpy[3], total_bias[3], dt, qnorm;
    uint32_t last_us, sequence, read_errors;
    unsigned failures, status;
    int calibrated_ok, initialized, have_timestamp;
} ImuService;
void ImuServiceInit(ImuService *s, const ImuCalibration *cal, int calibration_valid);
/* Called once per poll; read_result=0 is a fresh sample. Missing/error samples
   NEVER propagate the EKF. Startup requires 100 stationary fresh samples. */
void ImuServiceStep(ImuService *s, const ImuSample *sample, int read_result);
#endif
