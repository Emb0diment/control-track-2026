#ifndef APP_RUNTIME_H
#define APP_RUNTIME_H
#include <stdint.h>
void AppStart(void); /* after CubeMX peripherals init, BEFORE vTaskStartScheduler */
void AppRxByteFromISR(uint8_t byte);
void AppRxErrorFromISR(void);
#endif
