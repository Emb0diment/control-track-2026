#ifndef CALIBRATION_BOARD_H
#define CALIBRATION_BOARD_H
#include "imu.h"
/* Replace this file ONLY with the header generated from your real six faces.
   Identity parameters allow RAW capture, but block live EKF until calibrated. */
#define IMU_CALIBRATION_VALID 0
static const ImuCalibration kCalibration = {{0, 0, 0}, {1, 1, 1}, {0, 0, 0}};
#endif
