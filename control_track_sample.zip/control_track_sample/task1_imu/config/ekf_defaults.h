#ifndef EKF_DEFAULTS_H
#define EKF_DEFAULTS_H
/* EXAMPLE tuning. Replace using stationary logs / noise analysis for your IMU.
   These are continuous-time process noise densities, not per-sample stddev. */
#define EKF_GYRO_NOISE 0.003f            /* rad / sqrt(s) */
#define EKF_BIAS_RW 0.0002f              /* (rad/s) / sqrt(s) */
#define EKF_ACCEL_DIRECTION_SIGMA 0.015f /* normalized direction, per update */
#define EKF_ACCEL_NORM_GATE 0.15f        /* relative to g */
#define EKF_DT_MIN 0.0005f               /* s */
#define EKF_DT_MAX 0.03f                 /* s */
#endif
