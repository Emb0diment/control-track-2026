/* Generated from input data: verify these are YOUR real sensor samples. */
#ifndef CALIBRATION_BOARD_H
#define CALIBRATION_BOARD_H
#include "imu.h"
#define IMU_CALIBRATION_VALID 0
static const ImuCalibration kCalibration={
{1.200102940e-01f,-1.792110056e-01f,9.097392112e-02f},{1.025080323e+00f,9.800342321e-01f,1.014975905e+00f},{1.799396239e-02f,-1.200340502e-02f,2.499904856e-02f}};
#endif
