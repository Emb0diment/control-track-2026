#include "peripherals.h"
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
void StrobeEmergencyOff(Strobe *s, int reason) {
    s->on = 0;
    s->hz = 0;
    s->duty = 0;
    s->ack = reason;
    if (reason == STROBE_ERR_DURATION)
        s->lockout = 1;
    if (s->pwm && s->pwm(s->ctx, 0, 0))
        s->ack = STROBE_ERR_HARDWARE;
}
void StrobeInit(Strobe *s, int (*pwm)(void *, float, float), void *ctx) {
    memset(s, 0, sizeof(*s));
    s->pwm = pwm;
    s->ctx = ctx;
    StrobeEmergencyOff(s, STROBE_ACK_OFF);
}
static void command(Strobe *s, uint32_t now) {
    s->line[s->used] = '\0';
    if (strcmp(s->line, "STROBE,OFF") == 0) {
        s->lockout = 0;
        StrobeEmergencyOff(s, STROBE_ACK_OFF);
        s->last_valid_ms = now;
        return;
    }
    if (strncmp(s->line, "STROBE,", 7) != 0) {
        StrobeEmergencyOff(s, STROBE_ERR_COMMAND);
        return;
    }
    char *end;
    errno = 0;
    const char *start = s->line + 7;
    float hz = strtof(start, &end);
    if (end == start || *end != ',' || errno) {
        StrobeEmergencyOff(s, STROBE_ERR_COMMAND);
        return;
    }
    start = end + 1;
    errno = 0;
    float duty = strtof(start, &end);
    if (end == start || *end != '\0' || errno) {
        StrobeEmergencyOff(s, STROBE_ERR_COMMAND);
        return;
    }
    if (!isfinite(hz) || !isfinite(duty) || hz < 0.5f || hz > 20 || duty <= 0 || duty > 0.1f) {
        StrobeEmergencyOff(s, STROBE_ERR_RANGE);
        return;
    }
    if (s->lockout) {
        StrobeEmergencyOff(s, STROBE_ERR_DURATION);
        return;
    }
    if (!s->pwm || s->pwm(s->ctx, hz, duty)) {
        StrobeEmergencyOff(s, STROBE_ERR_HARDWARE);
        return;
    }
    if (!s->on)
        s->start_ms = now;
    s->on = 1;
    s->hz = hz;
    s->duty = duty;
    s->last_valid_ms = now;
    s->ack = STROBE_ACK_ON;
}
void StrobeFeed(Strobe *s, char c, uint32_t now) {
    s->last_byte_ms = now;
    if (c == '\n') {
        if (!s->discard) {
            if (s->used && s->line[s->used - 1] == '\r')
                s->used--;
            command(s, now);
        }
        s->used = 0;
        s->discard = 0;
        return;
    }
    if (s->discard)
        return;
    if ((unsigned char)c < 32 && c != '\r') {
        s->discard = 1;
        StrobeEmergencyOff(s, STROBE_ERR_COMMAND);
        return;
    }
    if (s->used >= sizeof(s->line) - 1) {
        s->discard = 1;
        StrobeEmergencyOff(s, STROBE_ERR_OVERFLOW);
        return;
    }
    s->line[s->used++] = c;
}
void StrobePoll(Strobe *s, uint32_t now) {
    if ((s->used || s->discard) && (uint32_t)(now - s->last_byte_ms) > 500) {
        s->used = 0;
        s->discard = 0;
        StrobeEmergencyOff(s, STROBE_ERR_TIMEOUT);
    }
    if (s->on && (uint32_t)(now - s->last_valid_ms) > 2000)
        StrobeEmergencyOff(s, STROBE_ERR_TIMEOUT);
    if (s->on && (uint32_t)(now - s->start_ms) >= 10000)
        StrobeEmergencyOff(s, STROBE_ERR_DURATION);
}
