#include "imu_service.h"
#include <math.h>
#include <string.h>
void ImuServiceInit(ImuService *s, const ImuCalibration *cal, int valid) {
    memset(s, 0, sizeof(*s));
    s->cal = *cal;
    s->calibrated_ok = valid;
    s->status = valid ? IMU_INITIALIZING : IMU_CAL_REQUIRED;
}
void ImuServiceStep(ImuService *s, const ImuSample *v, int result) {
    if (result != 0) {
        s->failures++;
        s->read_errors++;
        s->status |= IMU_STALE;
        if (s->failures >= 5) {
            s->status |= IMU_OFFLINE;
            s->initialized = 0;
            s->have_timestamp = 0;
            memset(&s->startup, 0, sizeof(s->startup));
        }
        return;
    }
    for (int i = 0; i < 3; i++)
        if (!isfinite(v->a[i]) || !isfinite(v->w[i])) {
            ImuServiceStep(s, v, -1);
            return;
        }
    s->failures = 0;
    s->raw = *v;
    s->sequence++;
    s->status = s->calibrated_ok ? 0 : IMU_CAL_REQUIRED;
    ImuApplyCalibration(&s->cal, v, &s->calibrated);
    float dt = s->have_timestamp ? (uint32_t)(v->stamp_us - s->last_us) * 1e-6f : 0;
    s->last_us = v->stamp_us;
    s->have_timestamp = 1;
    s->dt = dt;
    if (!s->calibrated_ok)
        return;
    if (s->initialized) {
        int rc = ImuEkfUpdate(&s->ekf, s->calibrated.w, s->calibrated.a, dt);
        if (rc < 0) {
            s->status = rc == IMU_EKF_BAD_INPUT ? IMU_BAD_DT : IMU_NUMERIC_FAULT;
            s->initialized = 0;
            memset(&s->startup, 0, sizeof(s->startup));
            return;
        }
        if (rc == IMU_EKF_ACCEL_SKIPPED)
            s->status |= IMU_ACCEL_REJECTED;
    } else {
        s->status |= IMU_INITIALIZING;
        float n = 0, wn = 0;
        for (int i = 0; i < 3; i++) {
            n += s->calibrated.a[i] * s->calibrated.a[i];
            wn += s->calibrated.w[i] * s->calibrated.w[i];
        }
        if (fabsf(sqrtf(n) - IMU_G) > 0.1f * IMU_G || sqrtf(wn) > 0.08f) {
            memset(&s->startup, 0, sizeof(s->startup));
            return;
        }
        ImuStatsPush(&s->startup, &s->calibrated);
        if (s->startup.n < 100)
            return;
        float a[3];
        int stationary = 1;
        for (int i = 0; i < 3; i++) {
            a[i] = (float)s->startup.mean[i];
            if (sqrt(s->startup.m2[i] / 99) > 0.15 || sqrt(s->startup.m2[i + 3] / 99) > 0.02)
                stationary = 0;
        }
        if (!stationary || ImuEkfInit(&s->ekf, a, NULL)) {
            memset(&s->startup, 0, sizeof(s->startup));
            return;
        }
        s->initialized = 1;
        s->status = 0;
    }
    ImuEkfGetEuler(&s->ekf, s->rpy);
    s->qnorm = 0;
    for (int i = 0; i < 4; i++)
        s->qnorm += s->ekf.q[i] * s->ekf.q[i];
    s->qnorm = sqrtf(s->qnorm);
    for (int i = 0; i < 3; i++)
        s->total_bias[i] = s->cal.gyro_bias[i] + s->ekf.bias[i];
}
