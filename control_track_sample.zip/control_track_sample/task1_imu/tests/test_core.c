#include "imu.h"
#include "imu_service.h"
#include "peripherals.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static int pwm(void *p, float f, float d) {
    float *v = p;
    v[0] = f;
    v[1] = d;
    return 0;
}
static void send(Strobe *s, const char *p, uint32_t t) {
    for (; *p; p++)
        StrobeFeed(s, *p, t);
}
static uint8_t regs[256];
static int rd(void *p, uint8_t a, uint8_t r, uint8_t *v, size_t n) {
    (void)p;
    assert(a == 0x68);
    memcpy(v, regs + r, n);
    return 0;
}
static int wr(void *p, uint8_t a, uint8_t r, uint8_t v) {
    (void)p;
    assert(a == 0x68);
    regs[r] = v;
    return 0;
}
static void delay(void *p, unsigned t) {
    (void)p;
    (void)t;
}
int main(void) {
    float a[3] = {0, 0, IMU_G}, w[3] = {0, 0, 0};
    ImuEkf e;
    assert(ImuEkfInit(&e, a, NULL) == 0);
    for (int i = 0; i < 10000; i++)
        assert(ImuEkfUpdate(&e, w, a, .005f) == 0);
    float rpy[3];
    ImuEkfGetEuler(&e, rpy);
    assert(fabsf(rpy[0]) + fabsf(rpy[1]) < 1e-5f);
    ImuEkf before = e;
    assert(ImuEkfUpdate(&e, w, a, 0) == -1);
    assert(memcmp(&before, &e, sizeof(e)) == 0);
    float bad[3] = {NAN, 0, 0};
    assert(ImuEkfUpdate(&e, bad, a, .005f) == -1);
    assert(memcmp(&before, &e, sizeof(e)) == 0);
    float high[3] = {0, 0, 2 * IMU_G};
    assert(ImuEkfUpdate(&e, w, high, .005f) == 1);
    /* Nonzero roll/pitch init and gravity convention roundtrip. */
    float q[4] = {1, 0, 0, 0}, h[3], rate[3] = {.4f, -.3f, .1f};
    ImuQuatStep(q, rate, 1);
    ImuGravityBody(q, h);
    for (int i = 0; i < 3; i++)
        h[i] *= IMU_G;
    assert(ImuEkfInit(&e, h, NULL) == 0);
    float hh[3];
    ImuGravityBody(e.q, hh);
    for (int i = 0; i < 3; i++)
        assert(fabsf(hh[i] - h[i] / IMU_G) < 1e-5f);
    /* Observable residual biases converge; gravity alone cannot fix vertical bias. */
    assert(ImuEkfInit(&e, a, NULL) == 0);
    float biased[3] = {.015f, -.012f, .02f};
    for (int i = 0; i < 8000; i++)
        assert(ImuEkfUpdate(&e, biased, a, .005f) >= 0);
    assert(fabsf(e.bias[0] - .015f) < .002f && fabsf(e.bias[1] + .012f) < .002f);
    e.freeze_bias = 1;
    float save[3];
    memcpy(save, e.bias, sizeof(save));
    for (int i = 0; i < 100; i++)
        assert(ImuEkfUpdate(&e, biased, a, .005f) >= 0);
    assert(memcmp(save, e.bias, sizeof(save)) == 0);
    /* Rotating body, exact synthetic gravity and gyro; detects sign/convention bugs. */
    assert(ImuEkfInit(&e, a, NULL) == 0);
    q[0] = 1;
    q[1] = q[2] = q[3] = 0;
    for (int k = 0; k < 5000; k++) {
        float ww[3] = {.4f * sinf(k * .005f), .3f * cosf(k * .003f), .1f};
        ImuQuatStep(q, ww, .005f);
        ImuGravityBody(q, h);
        for (int i = 0; i < 3; i++)
            h[i] *= IMU_G;
        assert(ImuEkfUpdate(&e, ww, h, .005f) >= 0);
        float dot = 0, qn = 0;
        for (int i = 0; i < 4; i++) {
            dot += q[i] * e.q[i];
            qn += e.q[i] * e.q[i];
        }
        assert(fabsf(dot) > .999f && fabsf(qn - 1) < 1e-5f);
        /* Cholesky check of covariance positive definiteness. */
        float L[6][6] = {{0}};
        for (int i = 0; i < 6; i++)
            for (int j = 0; j <= i; j++) {
                float v = e.P[i][j];
                for (int m = 0; m < j; m++)
                    v -= L[i][m] * L[j][m];
                if (i == j) {
                    assert(v > 0);
                    L[i][j] = sqrtf(v);
                } else
                    L[i][j] = v / L[j][j];
            }
    }
    ImuStats fs[6] = {{0}};
    for (int j = 0; j < 6; j++)
        for (int k = 0; k < 200; k++) {
            ImuSample v = {{.1f, -.2f, .3f}, {.01f, -.02f, .03f}, 0};
            v.a[j / 2] += (j % 2 ? -1 : 1) * IMU_G / 1.02f;
            ImuStatsPush(&fs[j], &v);
        }
    ImuCalibration c;
    assert(ImuCalibrate(fs, &c) == 0);
    assert(fabsf(c.scale[1] - 1.02f) < 1e-6f);
    fs[1] = fs[0];
    assert(ImuCalibrate(fs, &c) < 0);
    regs[0x75] = 0x68;
    Mpu6050 m = {NULL, rd, wr, delay, 0x68};
    assert(Mpu6050Init(&m) == 0);
    regs[0x3A] = 1;
    regs[0x3B] = 0x20;
    regs[0x43] = 0x19;
    regs[0x44] = 0x96;
    ImuSample sample;
    assert(Mpu6050Read(&m, &sample, 123) == 0);
    assert(fabsf(sample.a[0] - IMU_G) < 1e-6f);
    assert(fabsf(sample.w[0] - 100 * IMU_PI / 180) < 1e-5f);
    regs[0x3A] = 0;
    assert(Mpu6050Read(&m, &sample, 123) == 1);
    float v[2];
    Strobe s;
    StrobeInit(&s, pwm, v);
    send(&s, "STROBE,5.0,0.10\n", 100);
    assert(s.on && v[0] == 5);
    send(&s, "STROBE,nan,0.1\n", 200);
    assert(!s.on && s.ack < 0 && v[1] == 0);
    send(&s, "STROBE,5,0.1junk\n", 300);
    assert(!s.on);
    send(&s, "STROBE,5,0.1\n", 400);
    StrobePoll(&s, 2401);
    assert(!s.on && s.ack == STROBE_ERR_TIMEOUT);
    send(&s, "STROBE,5,0.1\n", 3000);
    for (int i = 0; i < 60; i++)
        StrobeFeed(&s, 'A', 3001);
    assert(!s.on);
    StrobeFeed(&s, '\n', 3001);
    send(&s, "STROBE,5,0.1\n", 4000);
    send(&s, "STROBE,OFF\r\n", 4010);
    assert(!s.on && s.ack == 2);
    send(&s, "STROBE,5,0.1\n", 5000);
    for (int i = 1; i <= 10; i++) {
        send(&s, "STROBE,5,0.1\n", 5000 + i * 1000);
        StrobePoll(&s, 5000 + i * 1000);
    }
    assert(!s.on && s.ack == STROBE_ERR_DURATION);
    send(&s, "STROBE,5,0.1\n", 16000);
    assert(!s.on && s.lockout);
    send(&s, "STROBE,OFF\n", 16001);
    send(&s, "STROBE,5,0.1\n", UINT32_MAX - 100);
    StrobePoll(&s, 2100);
    assert(!s.on);
    float channels[VOFA_CHANNELS] = {1};
    uint8_t frame[VOFA_FRAME_BYTES];
    assert(VofaEncode(channels, frame) == sizeof(frame));
    assert(frame[2] == 0x80 && frame[3] == 0x3f && frame[sizeof(frame) - 1] == 0x7f);
    ImuCalibration identity;
    ImuCalibrationIdentity(&identity);
    ImuService svc;
    ImuServiceInit(&svc, &identity, 0);
    ImuSample still = {{0, 0, IMU_G}, {0, 0, 0}, 0};
    ImuServiceStep(&svc, &still, 0);
    assert(svc.status == IMU_CAL_REQUIRED && !svc.initialized);
    ImuServiceInit(&svc, &identity, 1);
    for (int i = 0; i < 120; i++) {
        still.stamp_us += 5000;
        ImuServiceStep(&svc, &still, 0);
    }
    assert(svc.initialized && svc.status == 0);
    for (int i = 0; i < 5; i++)
        ImuServiceStep(&svc, &still, -1);
    assert((svc.status & IMU_OFFLINE) && !svc.initialized);
    for (int i = 0; i < 120; i++) {
        still.stamp_us += 5000;
        ImuServiceStep(&svc, &still, 0);
    }
    assert(svc.initialized && svc.status == 0);
    still.stamp_us += 100000;
    ImuServiceStep(&svc, &still, 0);
    assert((svc.status & IMU_BAD_DT) && !svc.initialized);
    ImuServiceInit(&svc, &identity, 1);
    still.stamp_us = UINT32_MAX - 200000;
    for (int i = 0; i < 120; i++) {
        still.stamp_us += 5000;
        ImuServiceStep(&svc, &still, 0);
    }
    assert(svc.initialized && svc.status == 0);
    puts("PASS: calibration, ESKF gravity/bias/dynamic/PSD, invalid input, MPU registers, strobe, "
         "VOFA, application lifecycle");
    return 0;
}
