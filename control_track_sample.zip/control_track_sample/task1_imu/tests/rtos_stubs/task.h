#include "FreeRTOS.h"
typedef void *TaskHandle_t;
TickType_t xTaskGetTickCount(void);
void vTaskDelay(TickType_t);
void vTaskDelayUntil(TickType_t *, TickType_t);
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t);
TaskHandle_t xTaskCreateStatic(void (*fn)(void *), const char *, uint32_t, void *, UBaseType_t,
                               StackType_t *, StaticTask_t *);
