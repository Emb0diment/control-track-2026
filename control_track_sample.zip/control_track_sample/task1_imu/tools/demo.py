"""Generate clearly marked SYNTHETIC data, run the C implementation, and plot.
Requires numpy and matplotlib. No Python EKF implementation is used.
"""
from pathlib import Path
import subprocess,json,os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(2026);g=9.80665
scale=np.array([1.025,.98,1.015]);offset=np.array([.12,-.18,.09]);bias=np.array([.018,-.012,.025])
rows=[]
for face in range(6):
 a=np.zeros(3);a[face//2]=(1 if face%2==0 else -1)*g
 for k in range(600):rows.append([face,k*.005,*(a/scale+offset+rng.normal(0,.025,3)),*(bias+rng.normal(0,.001,3))])
np.savetxt(root/'data/SYNTHETIC_six_faces.csv',rows,delimiter=',',header='face,timestamp_s,ax_mps2,ay_mps2,az_mps2,gx_radps,gy_radps,gz_radps',comments='',fmt=['%d']+['%.9f']*7)
t=np.arange(8001)*.005
# Smooth turn-on and turn-off, stationary startup and terminal interval.
env=np.where(t<3,0,np.where(t<5,(1-np.cos(np.pi*(t-3)/2))/2,np.where(t<28,1,np.where(t<30,(1+np.cos(np.pi*(t-28)/2))/2,0))))
r=.45*np.sin(.7*t)*env;p=.32*np.sin(.5*t)*env;y=.25*np.sin(.3*t)*env
rd=np.gradient(r,.005);pd=np.gradient(p,.005);yd=np.gradient(y,.005)
w=np.column_stack([rd-yd*np.sin(p),pd*np.cos(r)+yd*np.sin(r)*np.cos(p),-pd*np.sin(r)+yd*np.cos(r)*np.cos(p)])
a=g*np.column_stack([-np.sin(p),np.sin(r)*np.cos(p),np.cos(r)*np.cos(p)])
burst=(t>=12)&(t<13);a[burst,2]+=4
araw=a/scale+offset+rng.normal(0,.065,a.shape)
residual=np.column_stack([.006+.001*np.sin(t*.1),-.004+.001*np.cos(t*.12),np.full_like(t,.003)])
graw=w+bias+residual+rng.normal(0,.003,w.shape)
np.savetxt(root/'data/SYNTHETIC_dynamic.csv',np.column_stack([t,araw,graw]),delimiter=',',header='timestamp_s,ax_mps2,ay_mps2,az_mps2,gx_radps,gy_radps,gz_radps',comments='',fmt='%.9f')
np.savetxt(root/'data/SYNTHETIC_truth.csv',np.column_stack([t,r,p,y]),delimiter=',',header='timestamp_s,roll_rad,pitch_rad,yaw_rad',comments='',fmt='%.9f')
exe=root/('build/imu_cli.exe' if os.name=='nt' else 'build/imu_cli');cal=root/'results/SYNTHETIC_calibration.txt';output=root/'results/SYNTHETIC_replay.csv'
subprocess.run([str(exe),'calibrate',str(root/'data/SYNTHETIC_six_faces.csv'),str(cal)],check=True)
subprocess.run([str(exe),'replay',str(root/'data/SYNTHETIC_dynamic.csv'),str(cal),str(output)],check=True)
z=np.genfromtxt(output,delimiter=',',names=True);tt=z['timestamp_s'];truth=np.column_stack([np.interp(tt,t,r),np.interp(tt,t,p)])
metrics={'data_origin':'SYNTHETIC ONLY; C algorithm executed on host, no hardware validation','samples':len(z),'qnorm_max_error':float(np.max(np.abs(z['qnorm']-1))),'accel_update_skip_fraction':float(np.mean(z['status']==1))}
clean=(tt>=2)&~((tt>=12)&(tt<14))
for name in ['acc','gyro','ekf']:
 est=np.column_stack([z[f'{name}_roll'],z[f'{name}_pitch']]);err=np.arctan2(np.sin(est-truth),np.cos(est-truth))
 metrics[name+'_clean_RMS_rad']=np.sqrt(np.mean(err[clean]**2,axis=0)).tolist()
assert metrics['qnorm_max_error']<1e-3
assert max(metrics['ekf_clean_RMS_rad'])<.03
assert all(e<a for e,a in zip(metrics['ekf_clean_RMS_rad'],metrics['acc_clean_RMS_rad']))
assert all(e<a for e,a in zip(metrics['ekf_clean_RMS_rad'],metrics['gyro_clean_RMS_rad']))
(root/'results/SYNTHETIC_metrics.json').write_text(json.dumps(metrics,indent=2))
for typ,unit in [('a','m/s^2'),('g','rad/s')]:
 fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True)
 for i,axis in enumerate('xyz'):
  axs[i].plot(tt,z['raw_'+typ+axis],label='raw',alpha=.65);axs[i].plot(tt,z['cal_'+typ+axis],label='calibrated');axs[i].set_ylabel(f'{typ}{axis} ({unit})');axs[i].grid(True)
 axs[0].legend();axs[-1].set_xlabel('time (s)');fig.suptitle('SYNTHETIC data - '+('accelerometer' if typ=='a' else 'gyroscope'));fig.tight_layout();fig.savefig(root/f'results/SYNTHETIC_{typ}_calibration.png',dpi=140);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(11,8),sharex=True)
for i,axis in enumerate(['roll','pitch']):
 for name in ['acc','gyro','ekf']:axs[i].plot(tt,z[f'{name}_{axis}'],label=name,alpha=.8,lw=1)
 axs[i].plot(tt,truth[:,i],'k--',label='truth');axs[i].axvspan(12,13,color='orange',alpha=.2);axs[i].set_ylabel(axis+' (rad)');axs[i].grid(True);axs[i].legend()
axs[-1].set_xlabel('time (s)');fig.suptitle('SYNTHETIC motion - C ESKF output');fig.tight_layout();fig.savefig(root/'results/SYNTHETIC_attitude.png',dpi=140);plt.close(fig)
fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True)
for i,axis in enumerate('xyz'):
 axs[i].plot(tt,z['bias_'+axis],label='static + estimated residual');axs[i].plot(t,bias[i]+residual[:,i],'k--',label='synthetic truth');axs[i].set_ylabel('b'+axis+' (rad/s)');axs[i].grid(True)
axs[0].legend();axs[-1].set_xlabel('time (s)');fig.suptitle('SYNTHETIC gyro bias - vertical component not guaranteed observable');fig.tight_layout();fig.savefig(root/'results/SYNTHETIC_bias.png',dpi=140);plt.close(fig)
# Actual six-face calibration residuals (synthetic input).
v=np.array(rows);cc=np.loadtxt(cal);means=[]
for j in range(6):
 f=v[v[:,0]==j];ac=(f[:,2:5]-cc[0])*cc[1];gc=f[:,5:8]-cc[2]
 means.append([j,*np.mean(f[:,2:5],axis=0),*np.mean(ac,axis=0),*np.mean(f[:,5:8],axis=0),*np.mean(gc,axis=0)])
np.savetxt(root/'results/SYNTHETIC_face_summary.csv',means,delimiter=',',header='face,raw_ax,raw_ay,raw_az,cal_ax,cal_ay,cal_az,raw_gx,raw_gy,raw_gz,cal_gx,cal_gy,cal_gz',comments='')
print(json.dumps(metrics,indent=2))
