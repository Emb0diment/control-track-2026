"""Plot any C replay output (real or synthetic), without inventing ground truth."""
import argparse
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('csv',type=Path);p.add_argument('--out',type=Path,default=Path('results/real_plots'));args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
z=np.genfromtxt(args.csv,delimiter=',',names=True);t=z['timestamp_s']
if z.size<2:raise SystemExit('Not enough replay samples')
for key,label in [('a','acceleration (m/s^2)'),('g','angular velocity (rad/s)')]:
 fig,axs=plt.subplots(3,1,figsize=(10,8),sharex=True)
 for ax,axis in zip(axs,'xyz'):
  ax.plot(t,z['raw_'+key+axis],label='raw');ax.plot(t,z['cal_'+key+axis],label='calibrated');ax.set_ylabel(axis);ax.grid(True)
 axs[0].legend();axs[-1].set_xlabel('time (s)');fig.suptitle(label);fig.tight_layout();fig.savefig(args.out/(key+'_calibration.png'));plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True)
for ax,axis in zip(axs,['roll','pitch']):
 for name in ['acc','gyro','ekf']:ax.plot(t,z[name+'_'+axis],label=name)
 ax.set_ylabel(axis+' (rad)');ax.legend();ax.grid(True)
axs[-1].set_xlabel('time (s)');fig.tight_layout();fig.savefig(args.out/'attitude.png');plt.close(fig)
fig,axs=plt.subplots(3,1,figsize=(10,7),sharex=True)
for ax,axis in zip(axs,'xyz'):ax.plot(t,z['bias_'+axis]);ax.set_ylabel('b'+axis+' (rad/s)');ax.grid(True)
axs[-1].set_xlabel('time (s)');fig.tight_layout();fig.savefig(args.out/'bias.png');plt.close(fig)
print('Max quaternion norm error:',float(np.max(np.abs(z['qnorm']-1))))
print('No absolute attitude error is claimed without a real reference instrument.')
