"""Combine six capture CSVs without changing their face labels."""
import argparse,csv
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('inputs',nargs=6,type=Path);p.add_argument('--output',required=True,type=Path);args=p.parse_args()
rows=[];header=None
for f in args.inputs:
 with f.open() as fp:
  reader=csv.reader(fp);h=next(reader)
  if h[0]!='face' or (header is not None and h!=header):p.error('Mismatched headers or missing face column')
  header=h;rows.extend(reader)
counts={i:sum(int(r[0])==i for r in rows) for i in range(6)}
if min(counts.values())<100:p.error('Each face requires >=100 samples')
args.output.parent.mkdir(parents=True,exist_ok=True)
with args.output.open('w',newline='') as f:w=csv.writer(f);w.writerow(header);w.writerows(rows)
print(counts)
