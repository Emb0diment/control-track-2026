"""Read the documented 32-channel JustFloat stream and preserve raw SI data.
Example: python tools/capture.py --port COM5 --seconds 10 --face 0 --output data/real_px.csv
Close VOFA+ first: one program owns a serial port at a time.
"""
from pathlib import Path
import argparse,csv,struct,time,math,json
import serial
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--port',required=True);p.add_argument('--baud',type=int,default=115200)
p.add_argument('--seconds',type=float,default=10);p.add_argument('--face',type=int,choices=range(6))
p.add_argument('--output',type=Path,required=True);args=p.parse_args()
if args.seconds<=0:p.error('--seconds must be positive')
args.output.parent.mkdir(parents=True,exist_ok=True)
fields=['timestamp_s','ax_mps2','ay_mps2','az_mps2','gx_radps','gy_radps','gz_radps']
allfields=['time_s','raw_ax','raw_ay','raw_az','raw_gx','raw_gy','raw_gz','cal_ax','cal_ay','cal_az','cal_gx','cal_gy','cal_gz','roll_rad','pitch_rad','yaw_rad','bias_x','bias_y','bias_z','dt_s','qnorm','status','sequence','exec_us','jitter_us','stack_words','skipped','read_errors','rx_errors','strobe_ack','strobe_hz','strobe_duty']
buf=bytearray();tail=b'\x00\x00\x80\x7f';count=0;discarded=0;lastseq=None;last_t=None;epoch=0
with serial.Serial(args.port,args.baud,timeout=.1) as ser,args.output.open('w',newline='') as f,args.output.with_suffix('.telemetry.csv').open('w',newline='') as tf:
 w=csv.writer(f);w.writerow((['face'] if args.face is not None else [])+fields)
 tw=csv.writer(tf);tw.writerow(allfields);deadline=time.monotonic()+args.seconds
 while time.monotonic()<deadline:
  buf.extend(ser.read(max(1,ser.in_waiting)))
  while True:
   i=buf.find(tail)
   if i<0:
    if len(buf)>4096:buf=buf[-132:];discarded+=1
    break
   if i<128:del buf[:i+4];discarded+=1;continue
   frame=bytes(buf[i-128:i]);del buf[:i+4];v=struct.unpack('<32f',frame)
   if not all(math.isfinite(x) for x in v):discarded+=1;continue
   tw.writerow(v)
   if int(v[21])&(4|64) or v[22]==lastseq:continue
   # Sensor timer wraps every ~71.6 minutes. Never silently accept board reboot.
   if lastseq is not None and v[22]<lastseq:raise RuntimeError('Board sequence reset: start a new recording.')
   lastseq=v[22]
   if last_t is not None and v[0]<last_t:
    if last_t-v[0]>4000:epoch+=4294.967296
    else:raise RuntimeError('Nonmonotonic sensor time')
   last_t=v[0];w.writerow(([args.face] if args.face is not None else [])+[v[0]+epoch,*v[1:7]]);count+=1
meta={'origin':'USER_SERIAL_CAPTURE','port':args.port,'baud':args.baud,'face':args.face,'accepted_samples':count,'framing_discards':discarded,'note':'No checksum in JustFloat; inspect telemetry status and sample gaps. Raw units: SI.'}
args.output.with_suffix('.metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps(meta,indent=2))
if count<100:raise SystemExit('Too few samples: capture at least 100 per static face.')
