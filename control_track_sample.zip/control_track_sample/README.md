# 26 电控组赛道：分层工程样例

先解压整个文件夹，再运行。不要只取一个 C 文件。

## 先用哪个入口

| 目标 | 入口 | 环境 |
|---|---|---|
| 一键看 IMU 合成演示 | 在本文件夹运行 `python run.py` | Python + GCC/Clang |
| 只做 C 编译与测试 | `python run.py --check-only` | Python + GCC/Clang，无绘图库需求 |
| 运行倒立摆 | MATLAB 当前目录切换到 task2_pendulum，再执行 `metrics = run_sample` | MATLAB + Simulink |
| STM32 实际采集与运行 | task1_imu/docs/HARDWARE.md | 真实开发板、MPU6050、CubeMX/IDE |

第一次运行 IMU 完整演示前安装依赖：

```bash
python -m pip install -r task1_imu/requirements.txt
python run.py
```

Windows 需先安装可从命令行调用的 GCC/Clang；例如 MSYS2 UCRT64 GCC。编译器缺失时入口会提示，不会偷偷安装或改系统环境。
无需安装 clang-format，它只用于本次源码排版，不是构建依赖。

## 包含内容

| 项目 | 交付 |
|---|---|
| 任务一 | C 静态标定、四元数误差状态 EKF、原始与处理后合成日志、对比图、真实采集工具 |
| 工程实现 | 独立驱动、应用状态机、FreeRTOS 三任务、快照队列、非阻塞串口 DMA 适配、掉线恢复 |
| 加分项 | VOFA 双向频闪命令、硬件 PWM 适配、参数检查、超时关闭与最长持续时间 |
| 进阶基础 | 零偏冻结/恢复接口、加速度观测自适应降权、传感器无关算法封装、磁力计扩展讨论 |
| 任务二 | 已有倒立摆 LQR、模型自动生成、限幅、三种子扰动、日志/曲线/指标导出 |

## 架构优先看这里

[IMU 分层架构](task1_imu/docs/ARCHITECTURE.md) → [接口定义](task1_imu/include/imu.h) → [应用状态机](task1_imu/app/imu_service.c) → [硬件接入](task1_imu/docs/HARDWARE.md)。

算法层与驱动、FreeRTOS、HAL 分离；配置集中在 config；电脑和板端复用同一份 C 核心。
倒立摆按参数设计、模型生成、运行统计分成三个 MATLAB 文件，模型内含 Plant / Controller / Disturbance / Saturation / Logging 五部分。

## 已验证与未验证

- 已完成：C 严格编译、核心与应用状态机测试、ASan/UBSan 检查（环境不支持泄漏检测）、合成日志经 C 核心回放、图表生成。
- FreeRTOS 适配器仅做声明桩语法检查，尚未在真实 SDK 或调度器上运行。
- STM32 HAL 文件是需接入 CubeMX 工程的参考适配，不是可直接烧录的完整固件。实际板型未提供。
- 没有真实 IMU 硬件，未完成自采六面/动态数据、板端实时性测量和 VOFA 实机展示。
- 当前没有 MATLAB/Simulink，模型生成脚本尚未实机执行，包中不包含已生成的 SLX。
- 全部 SYNTHETIC 数据以及 task2 的 reference_check 都明确是合成/独立数值检查，不能代替赛事主验收。

## 已运行的 IMU 演示摘要

40 s、200 Hz 的合成动作经 C 核心处理后，干净时段 roll/pitch RMS 约 0.000594 / 0.000611 rad，四元数模长最大误差约 1.19e-7。
这只是给定合成模型与参数下的结果，不能当作真实传感器精度。完整数据来源、统计区间和限制见 task1_imu/docs/ALGORITHM.md。

默认板端标定无效，只开放原始采集。真实标定完成后才启用 EKF；附带的合成标定头也标记无效，避免误用。

[任务一逐项验收表](task1_imu/docs/ACCEPTANCE.md) 列出了代码位置、已完成验证和仍需硬件完成的工作。
