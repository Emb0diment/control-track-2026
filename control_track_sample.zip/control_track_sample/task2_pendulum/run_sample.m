function metrics = run_sample()
% Entry point. MATLAB + Simulink; no Control System Toolbox required.
root=fileparts(mfilename('fullpath')); addpath(root);
p=pendulum_params(); outdir=fullfile(root,'results');
if ~exist(outdir,'dir'), mkdir(outdir); end
mdl=build_pendulum(p,outdir);
cleanup=onCleanup(@() close_system(mdl,0)); %#ok<NASGU>
save(fullfile(outdir,'parameters.mat'),'p');
fid=fopen(fullfile(outdir,'environment.txt'),'w'); fprintf(fid,'%s\n',evalc('ver')); fclose(fid);
labels={'ideal','seed2026','seed2027','seed2028'};
seeds=[0 p.seeds]; metrics=table(); allruns=cell(4,1);
for k=1:4
 td=(0:round(p.T/p.Ts))'*p.Ts; dv=zeros(size(td));
 if k>1
  stream=RandStream('mt19937ar','Seed',seeds(k));
  active=td>=2 & td<8; dv(active)=p.sigma*randn(stream,nnz(active),1);
 end
 dist_data=[td dv];
 writetable(array2table(dist_data,'VariableNames',{'time_s','disturbance_Nm'}), ...
  fullfile(outdir,[labels{k} '_disturbance.csv']));
 in=Simulink.SimulationInput(mdl);
 in=in.setVariable('p',p,'Workspace',mdl);
 in=in.setVariable('dist_data',dist_data,'Workspace',mdl);
 result=sim(in); z=result.get('trace');
 t=z.Time(:); y=reshape(z.Data,numel(t),5);
 assert(all(isfinite(y(:))),'Nonfinite output');
 theta=y(:,1); u=y(:,4); sat=abs(y(:,3)-u)>1e-10;
 assert(max(abs(u))<=p.limit+1e-10,'Torque limit failed');
 % Fixed-step logs: integrate to avoid counting terminal sample twice.
 rms_time=@(v,mask) sqrt(trapz(t(mask),v(mask).^2)/(t(find(mask,1,'last'))-t(find(mask,1))));
 steady=t>=10; during=t>=2 & t<8;
 settling=settle(t,theta,p.band,0);
 recovery=NaN; if k>1, settling=NaN; recovery=settle(t,theta,p.band,8); end
 row=table(seeds(k),settling,recovery,max(abs(theta)),rms_time(theta,steady), ...
 rms_time(theta,during),max(abs(u)),rms_time(u,true(size(t))), ...
 sum(diff(t).*double(sat(1:end-1)))/(t(end)-t(1)), ...
 max(abs(theta))<=10*pi/180, ...
 'VariableNames',{'seed','settling_s','recovery_after8_s','max_abs_angle_rad', ...
 'steady_RMS_10to12_rad','disturbed_RMS_2to8_rad','torque_peak_Nm','torque_RMS_Nm','saturation_fraction','within_10deg'});
 metrics=[metrics;row]; %#ok<AGROW>
 logtable=array2table([t zeros(size(t)) y double(sat)],'VariableNames', ...
 {'time_s','target_rad','theta_rad','omega_radps','u_cmd_Nm','u_Nm','d_Nm','saturated'});
 writetable(logtable,fullfile(outdir,[labels{k} '_log.csv']));
 allruns{k}=logtable;
 f=figure('Visible','off','Color','w','Position',[100 100 1000 760]);
 subplot(4,1,1);plot(t,theta,t,zeros(size(t)),'--');ylabel('theta (rad)');grid on;title(labels{k});
 subplot(4,1,2);plot(t,y(:,2));ylabel('omega (rad/s)');grid on;
 subplot(4,1,3);plot(t,y(:,3),t,u,t,y(:,5));ylabel('torque (N m)');legend('command','applied','disturbance');grid on;
 subplot(4,1,4);stairs(t,double(sat));ylabel('saturated');xlabel('time (s)');ylim([-0.1 1.1]);grid on;
 print(f,fullfile(outdir,[labels{k} '.png']),'-dpng','-r150');close(f);
end
writetable(metrics,fullfile(outdir,'metrics.csv'));save(fullfile(outdir,'runs.mat'),'p','allruns','metrics');
disp(metrics);fprintf('Outputs: %s\n',outdir);
end
function ts=settle(t,a,band,start)
% First instant after start after which angle stays in band until simulation end.
i=find(t>=start); bad=find(abs(a(i))>band,1,'last');
if isempty(bad), ts=0; elseif bad==numel(i), ts=NaN; else, ts=t(i(bad+1))-start; end
end
