# 任务二样例：Simulink 单杆倒立摆 LQR 抗扰控制

## 样例状态

已提供模型生成代码、参数初始化、批量仿真、日志导出、指标统计和绘图代码。
当前制作环境没有 MATLAB/Simulink，尚未实际执行 MATLAB 脚本、编译模型或生成 .slx。
因此本包是“待 MATLAB 实机验证的工程样例”，不是已经完成验收的参赛提交物。
reference_check 中是独立 Python 数值检查及其日志，明确不能代替赛道要求的 Simulink 结果。
所有物理参数均为赛道给出的示例参数，没有实测依据；控制权重为本样例设计值。

## 最短运行步骤

1. 将整个压缩包解压到一个可写目录，保留全部 .m 文件在同一文件夹。
2. 在 MATLAB 中把当前文件夹切换到该目录。需要 MATLAB 和 Simulink；建议 R2020b 或更新版本，具体版本兼容性尚未实机验证。
3. 执行 `metrics = run_sample`。
4. 脚本自动创建 results/pendulum_lqr_sample.slx，并运行无扰动和三个随机种子工况。
5. 在 results 中查看 metrics.csv、四张结果图、四份完整状态日志、四份扰动输入、parameters.mat、runs.mat 和环境版本记录。
6. 用 `open_system(fullfile('results','pendulum_lqr_sample.slx'))` 打开生成模型。

重复运行会覆盖本包 results 中同名生成文件。如需保留旧结果，请先复制 results 文件夹。
若生成模型已经打开，请先关闭；生成器会拒绝重建打开的同名模型，以避免丢失未保存修改。
保存的模型内置无扰动默认数据。三种扰动通过 run_sample 的 SimulationInput 注入；直接点击模型运行按钮默认执行无扰动工况。

## 文件作用

| 文件 | 作用 |
|---|---|
| pendulum_params.m | 物理参数、控制器设计、黎卡提方程残差检查 |
| build_pendulum.m | 用标准模块搭建五个子系统，并保存原生 SLX |
| run_sample.m | 四组仿真、种子与输入保存、指标和曲线导出 |
| check_reference.py | 可选独立数值交叉检查；不参与 MATLAB 主流程 |
| reference_check/ | 已运行的 Python 检查输出，非 Simulink 结果 |

## 模型与符号约定

直立为 theta=0；theta 增大方向为角度正方向，正力矩使角加速度增大。
这是固定转轴、输入为转轴力矩的单自由度模型，不是小车倒立摆。
l 表示转轴到质心距离，J 为关于转轴的等效转动惯量；不要擅自另用 ml² 替换给定 J。

J*theta_ddot = m*g*l*sin(theta) - b*theta_dot + u + d

x=[theta; omega]，在零点线性化：
A=[0,1; m*g*l/J,-b/J]，B=[0;1/J]。
目标为固定零角度；反馈采用 u_cmd=-K*x，u=clip(u_cmd,-0.5,0.5)。
正小偏角且角速度为零时，反馈力矩为负，抵抗不稳定的重力力矩。
Plant 中使用非线性 sin(theta)，线性模型只用于设计。
扰动 d 在执行器限幅之后加到被控对象力矩端。因此执行器受限于 ±0.5 N*m，执行器与外扰合力矩可以超过这个数值。

五个子系统：Plant / Controller / Disturbance / Saturation / Logging。
记录 theta、omega、限幅前后力矩、扰动力矩；导出时另补固定零目标与饱和标志。
没有测量噪声和观测器；假设角度、角速度均可准确获得，控制器为连续状态反馈。

## 参数与控制器

m=0.2 kg，g=9.80665 m/s²，l=0.15 m，J=0.006 kg*m²，b=0.002 N*m*s/rad。
初始 theta=5*pi/180 rad，omega=0 rad/s；内部及输出均使用 rad。
仿真长度 12 s；固定步长 RK4（ode4），步长 0.001 s。
LQR 代价为积分 x'*Q*x+u'*R*u，Q=diag([4,0.04])，R=1。
权重是示例设计值，分别惩罚角度、角速度与力矩；不是传感器噪声参数，也不是最优赛事调参结论。

令 c=m*g*l。对本例对角 Q，稳定解反馈增益可直接写为：
kp=c+sqrt(c²+Q11/R)
kd=-b+sqrt(b²+2*J*kp+Q22/R)
K=[kp,kd]

脚本重建 P，验证 A'*P+P*A-P*B/R*B'*P+Q 的残差、P 正定及闭环极点。
所以主流程不依赖 Control System Toolbox。如已安装，可用 lqr(p.A,p.B,p.Q,p.R) 对比。
增大 Q11 通常加强角度恢复，同时可能增加力矩和饱和；调参后必须重新运行四工况。
线性 LQR 仅保证线性无饱和模型的性质，本样例不声称任意大偏角都能恢复。

## 随机扰动与复现

标准差 0.02 N*m，离散周期 0.01 s，固定种子为 2026、2027、2028。
MATLAB 使用本地 RandStream('mt19937ar',...)，不依赖用户全局随机状态。
在 2<=t<8 s 生成随机力矩，8 s 起清零；样本间按零阶保持输入。
From Workspace 设置 Interpolate='off'、SampleTime=p.Ts，步长整除扰动周期。
保存每组实际输入 CSV，因此即便跨软件随机数实现不同，也可使用原始输入复核。
Python 独立检查使用 NumPy 的随机数算法，同一整数种子不意味着相同样本，不能把两者种子结果逐行当作一致性验证。

## 指标定义

- 无扰动调节时间：进入 ±0.5*pi/180 rad 容差带，并在余下仿真时间内不再离开的最早时间。未达到记 NaN；仅是有限仿真时域内的判据。
- 扰动工况：普通调节时间记 NaN，另记录 8 s 扰动撤除后重新持续进入相同容差带的恢复时间。
- 最大绝对角度：整个 0–12 s 的最大值（包含初始偏角）。
- 稳态角度 RMS：10–12 s 的时间积分 RMS。
- 扰动期间 RMS：记录时间戳满足 2<=t<8 的样本区间的时间积分 RMS；上边界最后样本为 7.999 s。
- 力矩峰值和 RMS：实际限幅后控制力矩，统计整个 0–12 s，不包括外扰。
- 饱和占比：abs(u_cmd-u)>1e-10 判定，以每个时间区间左端标志累计占用时间再除以总时长。
- within_10deg：所有记录样本绝对角度不超过 10*pi/180 rad；不等价于通用稳定性证明。

MATLAB 运行时会检查输出有限值、控制力矩限幅，另外输出是否满足最大角度限制。

## 已做的检查与待办

已做：独立非线性 RK4 仿真；解析 LQR 与 SciPy 黎卡提解交叉比较；四组工况有限值、角度上限及步长减半检查。
数值结果详见 reference_check/check_summary.json。Python 图表只展示独立检查。
尚待：在实际 MATLAB/Simulink 环境执行 run_sample，确认模块参数兼容、SLX 编译及四组仿真，再使用 results 中的结果作为参赛材料。
现场复核可修改 pendulum_params.m 中 theta0、sigma、seeds 后重跑。若改 Ts 或 h，需保持 Ts/h 为整数。
本包只覆盖任务二，不包含任务一的真实 IMU 数据、C EKF 或板端实时实现。

## 官方接口参考

- From Workspace（零阶保持、采样设置）：https://www.mathworks.com/help/simulink/slref/fromworkspace.html
- SimulationInput.setVariable（按工况注入模型工作区变量）：https://www.mathworks.com/help/simulink/slref/simulink.simulationinput.setvariable.html
