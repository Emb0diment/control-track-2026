function mdl = build_pendulum(p, outdir)
% Generates a native SLX. Existing generated file is replaced only in outdir.
mdl='pendulum_lqr_sample';
if bdIsLoaded(mdl), error('Close pendulum_lqr_sample before rebuilding.'); end
load_system('simulink'); new_system(mdl);
set_param(mdl,'SolverType','Fixed-step','Solver','ode4', ...
 'FixedStep',num2str(p.h,17),'StopTime',num2str(p.T), ...
 'ReturnWorkspaceOutputs','on');
% Model workspace defaults make the saved SLX runnable independently.
w=get_param(mdl,'ModelWorkspace'); assignin(w,'p',p);
assignin(w,'dist_data',[(0:p.Ts:p.T)' zeros(round(p.T/p.Ts)+1,1)]);
sub(mdl,'Plant',[550 100 740 250]);
sub(mdl,'Controller',[250 100 400 200]);
sub(mdl,'Disturbance',[260 290 410 350]);
sub(mdl,'Saturation',[440 100 510 160]);
sub(mdl,'Logging',[830 90 990 300]);
s=[mdl '/Plant'];
blk(s,'In1','simulink/Ports & Subsystems/In1',[20 35 45 55],'Port','1');
blk(s,'d','simulink/Ports & Subsystems/In1',[20 80 45 100],'Port','2');
blk(s,'Sum','simulink/Math Operations/Sum',[160 40 185 120],'Inputs','+++-');
blk(s,'InvJ','simulink/Math Operations/Gain',[215 60 270 95],'Gain','1/p.J');
blk(s,'Omega','simulink/Continuous/Integrator',[305 60 335 90],'InitialCondition','p.omega0');
blk(s,'Theta','simulink/Continuous/Integrator',[385 60 415 90],'InitialCondition','p.theta0');
blk(s,'Sin','simulink/Math Operations/Trigonometric Function',[380 160 430 190],'Operator','sin');
blk(s,'Gravity','simulink/Math Operations/Gain',[250 160 315 190],'Gain','p.m*p.g*p.l');
blk(s,'Damping','simulink/Math Operations/Gain',[235 235 300 265],'Gain','p.b');
blk(s,'theta','simulink/Ports & Subsystems/Out1',[495 60 520 80],'Port','1');
blk(s,'omega','simulink/Ports & Subsystems/Out1',[495 110 520 130],'Port','2');
wire(s,{'In1/1','Sum/1';'d/1','Sum/2';'Sum/1','InvJ/1';'InvJ/1','Omega/1';'Omega/1','Theta/1';'Theta/1','theta/1';'Omega/1','omega/1';'Theta/1','Sin/1';'Sin/1','Gravity/1';'Gravity/1','Sum/3';'Omega/1','Damping/1';'Damping/1','Sum/4'});
s=[mdl '/Controller'];
blk(s,'theta','simulink/Ports & Subsystems/In1',[20 30 45 50],'Port','1');
blk(s,'omega','simulink/Ports & Subsystems/In1',[20 95 45 115],'Port','2');
blk(s,'Ktheta','simulink/Math Operations/Gain',[80 25 140 55],'Gain','-p.K(1)');
blk(s,'Komega','simulink/Math Operations/Gain',[80 90 140 120],'Gain','-p.K(2)');
blk(s,'Sum','simulink/Math Operations/Sum',[180 45 205 100],'Inputs','++');
blk(s,'u_cmd','simulink/Ports & Subsystems/Out1',[250 65 275 85]);
wire(s,{'theta/1','Ktheta/1';'omega/1','Komega/1';'Ktheta/1','Sum/1';'Komega/1','Sum/2';'Sum/1','u_cmd/1'});
s=[mdl '/Saturation'];
blk(s,'In','simulink/Ports & Subsystems/In1',[20 40 45 60]);
blk(s,'Limit','simulink/Discontinuities/Saturation',[85 30 140 70],'UpperLimit','p.limit','LowerLimit','-p.limit');
blk(s,'Out','simulink/Ports & Subsystems/Out1',[190 40 215 60]);
wire(s,{'In/1','Limit/1';'Limit/1','Out/1'});
s=[mdl '/Disturbance'];
blk(s,'Samples','simulink/Sources/From Workspace',[20 30 145 70], ...
 'VariableName','dist_data','SampleTime','p.Ts','Interpolate','off');
blk(s,'Out','simulink/Ports & Subsystems/Out1',[210 40 235 60]); wire(s,{'Samples/1','Out/1'});
s=[mdl '/Logging']; names={'theta','omega','u_cmd','u','d'};
for k=1:5
 blk(s,names{k},'simulink/Ports & Subsystems/In1',[20 35*k 45 35*k+20],'Port',num2str(k));
end
blk(s,'Mux','simulink/Signal Routing/Mux',[100 30 105 205],'Inputs','5');
blk(s,'Trace','simulink/Sinks/To Workspace',[160 95 265 135], ...
 'VariableName','trace','SaveFormat','Timeseries','MaxDataPoints','inf','Decimation','1');
for k=1:5, add_line(s,[names{k} '/1'],['Mux/' num2str(k)],'autorouting','on'); end
wire(s,{'Mux/1','Trace/1'});
wire(mdl,{'Plant/1','Controller/1';'Plant/2','Controller/2';'Controller/1','Saturation/1';'Saturation/1','Plant/1';'Disturbance/1','Plant/2';'Plant/1','Logging/1';'Plant/2','Logging/2';'Controller/1','Logging/3';'Saturation/1','Logging/4';'Disturbance/1','Logging/5'});
save_system(mdl,fullfile(outdir,[mdl '.slx']));
end
function sub(m,n,pos)
add_block('built-in/Subsystem',[m '/' n],'Position',pos);
end
function blk(s,n,src,pos,varargin)
add_block(src,[s '/' n],'Position',pos,varargin{:});
end
function wire(s,pairs)
for j=1:size(pairs,1), add_line(s,pairs{j,1},pairs{j,2},'autorouting','on'); end
end
