function p = pendulum_params()
% All physical values below are EXAMPLE parameters from the task, not measurements.
p.m=0.2; p.g=9.80665; p.l=0.15; p.J=0.006; p.b=0.002;
p.limit=0.5; p.theta0=5*pi/180; p.omega0=0;
p.h=0.001; p.T=12; p.Ts=0.01; p.sigma=0.02;
p.seeds=[2026 2027 2028]; p.band=0.5*pi/180;
p.Q=diag([4 0.04]); p.R=1;
p.A=[0 1;p.m*p.g*p.l/p.J -p.b/p.J]; p.B=[0;1/p.J];
% Analytic continuous-time LQR for this 2-state system and diagonal Q.
% From B'*P/R = [kp kd] and A'*P+P*A-P*B/R*B'*P+Q=0.
c=p.m*p.g*p.l;
kp=c+sqrt(c*c+p.Q(1,1)/p.R);
kd=-p.b+sqrt(p.b*p.b+2*p.J*kp+p.Q(2,2)/p.R);
p.K=[kp kd];
P12=p.R*p.J*kp; P22=p.R*p.J*kd;
P11=(p.b/p.J)*P12-(c/p.J)*P22+P12*P22/(p.R*p.J^2);
p.P=[P11 P12;P12 P22];
res=p.A'*p.P+p.P*p.A-p.P*p.B/p.R*p.B'*p.P+p.Q;
assert(norm(res,'fro')<1e-9 && all(eig(p.P)>0));
assert(all(real(eig(p.A-p.B*p.K))<0));
assert(abs(p.Ts/p.h-round(p.Ts/p.h))<1e-10);
end
