"""Independent numerical check ONLY. Not a Simulink acceptance result.
NumPy's seeded normal samples differ from MATLAB. Do not compare seed rows bitwise.
Run: python check_reference.py (numpy, scipy, matplotlib required).
"""
from pathlib import Path
import csv, json
import numpy as np
from scipy.linalg import solve_continuous_are
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent/'reference_check'; root.mkdir(exist_ok=True)
m,g,l,J,b=.2,9.80665,.15,.006,.002
c=m*g*l; A=np.array([[0,1],[c/J,-b/J]]); B=np.array([[0],[1/J]])
Q=np.diag([4,.04]); P=solve_continuous_are(A,B,Q,np.array([[1.]])); K=(B.T@P)[0]
analytic=np.array([c+np.sqrt(c*c+4),0.]); analytic[1]=-b+np.sqrt(b*b+2*J*analytic[0]+.04)
assert np.allclose(K,analytic,atol=1e-10)
def run(seed,h):
    n=round(12/h); t=np.arange(n+1)*h; x=np.zeros((n+1,2));x[0]=[5*np.pi/180,0]
    d=np.zeros(1201)
    if seed: d[200:800]=np.random.default_rng(seed).normal(0,.02,600)
    stride=round(.01/h)
    def fun(z,dist):
        u=np.clip(-K@z,-.5,.5)
        return np.array([z[1],(c*np.sin(z[0])-b*z[1]+u+dist)/J])
    for i in range(n):
        z=x[i];dist=d[i//stride]
        k1=fun(z,dist);k2=fun(z+h*k1/2,dist);k3=fun(z+h*k2/2,dist);k4=fun(z+h*k3,dist)
        x[i+1]=z+h*(k1+2*k2+2*k3+k4)/6
    cmd=-x@K;u=np.clip(cmd,-.5,.5);sat=np.abs(cmd-u)>1e-10
    assert np.all(np.isfinite(x)) and np.max(np.abs(x[:,0]))<=10*np.pi/180
    band=.5*np.pi/180; idx=np.flatnonzero(np.abs(x[:,0])>band)
    ts=t[idx[-1]+1] if len(idx) and idx[-1]<n else (0 if not len(idx) else float('nan'))
    row=dict(seed=seed,max_abs_angle_rad=np.max(np.abs(x[:,0])),steady_RMS_rad=np.sqrt(np.mean(x[t>=10,0]**2)),torque_peak_Nm=np.max(np.abs(u)),saturation_fraction=np.mean(sat[:-1]),settling_s=ts if seed==0 else float('nan'))
    return t,x,u,d[np.minimum(np.arange(n+1)//stride,1200)],row
rows=[];fig,axes=plt.subplots(3,1,figsize=(10,8),sharex=True)
for seed in [0,2026,2027,2028]:
    t,x,u,d,row=run(seed,.001);tf,xf,uf,df,_=run(seed,.0005)
    delta=np.max(np.abs(x-xf[::2])); assert delta<1e-6
    row['step_halving_max_state_difference']=delta;rows.append(row)
    np.savetxt(root/f'python_seed{seed}.csv',np.column_stack([t,x,u,d]),delimiter=',',header='time_s,theta_rad,omega_radps,u_Nm,d_Nm',comments='')
    for ax,v in zip(axes,[x[:,0],x[:,1],u]):ax.plot(t,v,label=str(seed) if seed else 'ideal');ax.grid(True)
axes[0].set_ylabel('theta (rad)');axes[1].set_ylabel('omega (rad/s)');axes[2].set_ylabel('u (N m)');axes[2].set_xlabel('time (s)');axes[0].legend()
fig.suptitle('Independent Python check - NOT Simulink results');fig.tight_layout();fig.savefig(root/'reference_plot.png',dpi=150)
with open(root/'reference_metrics.csv','w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
info={'K':K.tolist(),'closed_loop_poles':np.linalg.eigvals(A-B@K[None,:]).tolist(),'rows':rows}
(root/'check_summary.json').write_text(json.dumps(info,indent=2))
print(json.dumps(info,indent=2))
