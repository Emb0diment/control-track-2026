"""Run the host IMU sample. MATLAB entry is task2_pendulum/run_sample.m."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
raise SystemExit(subprocess.call([sys.executable,str(root/'task1_imu/run_demo.py'),*sys.argv[1:]],cwd=root/'task1_imu'))
